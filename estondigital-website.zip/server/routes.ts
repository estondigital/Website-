import express, { type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSubmissionSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes should be prefixed with /api
  const apiRouter = express.Router();
  
  // Services API
  apiRouter.get("/services", async (req: Request, res: Response) => {
    try {
      const services = await storage.getServices();
      res.json(services);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch services" });
    }
  });

  apiRouter.get("/services/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid service ID" });
      }
      
      const service = await storage.getServiceById(id);
      if (!service) {
        return res.status(404).json({ message: "Service not found" });
      }
      
      res.json(service);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch service" });
    }
  });

  // Case Studies API
  apiRouter.get("/case-studies", async (req: Request, res: Response) => {
    try {
      const { industry, featured } = req.query;
      
      if (industry) {
        const caseStudies = await storage.getCaseStudiesByIndustry(industry as string);
        return res.json(caseStudies);
      }
      
      if (featured === 'true') {
        const featuredCaseStudies = await storage.getFeaturedCaseStudies();
        return res.json(featuredCaseStudies);
      }
      
      const allCaseStudies = await storage.getCaseStudies();
      res.json(allCaseStudies);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch case studies" });
    }
  });

  apiRouter.get("/case-studies/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid case study ID" });
      }
      
      const caseStudy = await storage.getCaseStudyById(id);
      if (!caseStudy) {
        return res.status(404).json({ message: "Case study not found" });
      }
      
      res.json(caseStudy);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch case study" });
    }
  });

  // Testimonials API
  apiRouter.get("/testimonials", async (req: Request, res: Response) => {
    try {
      const { featured } = req.query;
      
      if (featured === 'true') {
        const featuredTestimonials = await storage.getFeaturedTestimonials();
        return res.json(featuredTestimonials);
      }
      
      const allTestimonials = await storage.getTestimonials();
      res.json(allTestimonials);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch testimonials" });
    }
  });

  // Blog Posts API
  apiRouter.get("/blog-posts", async (req: Request, res: Response) => {
    try {
      const { category, featured } = req.query;
      
      if (category) {
        const categoryPosts = await storage.getBlogPostsByCategory(category as string);
        return res.json(categoryPosts);
      }
      
      if (featured === 'true') {
        const featuredPosts = await storage.getFeaturedBlogPosts();
        return res.json(featuredPosts);
      }
      
      const allPosts = await storage.getBlogPosts();
      res.json(allPosts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch blog posts" });
    }
  });

  apiRouter.get("/blog-posts/:slug", async (req: Request, res: Response) => {
    try {
      const { slug } = req.params;
      
      const post = await storage.getBlogPostBySlug(slug);
      if (!post) {
        return res.status(404).json({ message: "Blog post not found" });
      }
      
      res.json(post);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch blog post" });
    }
  });

  // Job Listings API
  apiRouter.get("/job-listings", async (req: Request, res: Response) => {
    try {
      const { active } = req.query;
      
      if (active === 'true') {
        const activeListings = await storage.getActiveJobListings();
        return res.json(activeListings);
      }
      
      const allListings = await storage.getJobListings();
      res.json(allListings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch job listings" });
    }
  });

  apiRouter.get("/job-listings/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid job listing ID" });
      }
      
      const jobListing = await storage.getJobListingById(id);
      if (!jobListing) {
        return res.status(404).json({ message: "Job listing not found" });
      }
      
      res.json(jobListing);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch job listing" });
    }
  });

  // Contact Form Submission API
  apiRouter.post("/contact", async (req: Request, res: Response) => {
    try {
      const submissionData = insertContactSubmissionSchema.parse(req.body);
      const submission = await storage.createContactSubmission(submissionData);
      res.status(201).json(submission);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        res.status(400).json({ message: validationError.message });
      } else {
        res.status(500).json({ message: "Failed to submit contact form" });
      }
    }
  });

  // Register the API router
  app.use("/api", apiRouter);

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
