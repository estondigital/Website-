import {
  users, type User, type InsertUser,
  contactSubmissions, type ContactSubmission, type InsertContactSubmission,
  services, type Service, type InsertService,
  caseStudies, type CaseStudy, type InsertCaseStudy,
  testimonials, type Testimonial, type InsertTestimonial,
  blogPosts, type BlogPost, type InsertBlogPost,
  jobListings, type JobListing, type InsertJobListing
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Contact form submissions
  createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission>;
  getContactSubmissions(): Promise<ContactSubmission[]>;

  // Services
  getServices(): Promise<Service[]>;
  getServiceById(id: number): Promise<Service | undefined>;
  createService(service: InsertService): Promise<Service>;
  
  // Case studies
  getCaseStudies(): Promise<CaseStudy[]>;
  getCaseStudyById(id: number): Promise<CaseStudy | undefined>;
  getCaseStudiesByIndustry(industry: string): Promise<CaseStudy[]>;
  getFeaturedCaseStudies(): Promise<CaseStudy[]>;
  createCaseStudy(caseStudy: InsertCaseStudy): Promise<CaseStudy>;
  
  // Testimonials
  getTestimonials(): Promise<Testimonial[]>;
  getFeaturedTestimonials(): Promise<Testimonial[]>;
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;
  
  // Blog posts
  getBlogPosts(): Promise<BlogPost[]>;
  getBlogPostById(id: number): Promise<BlogPost | undefined>;
  getBlogPostBySlug(slug: string): Promise<BlogPost | undefined>;
  getBlogPostsByCategory(category: string): Promise<BlogPost[]>;
  getFeaturedBlogPosts(): Promise<BlogPost[]>;
  createBlogPost(blogPost: InsertBlogPost): Promise<BlogPost>;
  
  // Job listings
  getJobListings(): Promise<JobListing[]>;
  getActiveJobListings(): Promise<JobListing[]>;
  getJobListingById(id: number): Promise<JobListing | undefined>;
  createJobListing(jobListing: InsertJobListing): Promise<JobListing>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private contactSubmissions: Map<number, ContactSubmission>;
  private services: Map<number, Service>;
  private caseStudies: Map<number, CaseStudy>;
  private testimonials: Map<number, Testimonial>;
  private blogPosts: Map<number, BlogPost>;
  private jobListings: Map<number, JobListing>;
  
  private currentUserId: number;
  private currentContactSubmissionId: number;
  private currentServiceId: number;
  private currentCaseStudyId: number;
  private currentTestimonialId: number;
  private currentBlogPostId: number;
  private currentJobListingId: number;

  constructor() {
    this.users = new Map();
    this.contactSubmissions = new Map();
    this.services = new Map();
    this.caseStudies = new Map();
    this.testimonials = new Map();
    this.blogPosts = new Map();
    this.jobListings = new Map();
    
    this.currentUserId = 1;
    this.currentContactSubmissionId = 1;
    this.currentServiceId = 1;
    this.currentCaseStudyId = 1;
    this.currentTestimonialId = 1;
    this.currentBlogPostId = 1;
    this.currentJobListingId = 1;
    
    // Initialize with sample data
    this.initializeData();
  }

  private initializeData() {
    // Add sample services
    const sampleServices: InsertService[] = [
      {
        title: "SEO Optimization",
        description: "Drive organic traffic and improve search rankings with our data-driven SEO strategies.",
        icon: "search",
        featured: true
      },
      {
        title: "Performance Marketing",
        description: "Maximize ROI with targeted campaigns across search, social, and display networks.",
        icon: "chart-line",
        featured: true
      },
      {
        title: "Branding",
        description: "Create a compelling brand identity that resonates with your target audience.",
        icon: "paint-brush",
        featured: true
      },
      {
        title: "Email Marketing",
        description: "Nurture leads and drive conversions with strategic email campaigns.",
        icon: "envelope",
        featured: true
      },
      {
        title: "Video Production",
        description: "Engage your audience with high-quality video content that drives results.",
        icon: "video",
        featured: true
      },
      {
        title: "Social Media Management",
        description: "Build your brand presence and community on key social platforms.",
        icon: "globe",
        featured: true
      }
    ];
    
    sampleServices.forEach(service => this.createService(service));
    
    // Add sample case studies
    const sampleCaseStudies: InsertCaseStudy[] = [
      {
        title: "3.5x ROAS Improvement for E-commerce Brand",
        client: "Fashion Retailer",
        industry: "Ecommerce",
        description: "Helping an online fashion retailer boost their return on ad spend through optimized PPC campaigns.",
        challenge: "Low conversion rates and high cost per acquisition from existing ad campaigns.",
        solution: "Restructured campaign architecture, implemented advanced audience targeting, and optimized ad creative.",
        results: JSON.stringify({
          beforeROAS: 1.2,
          afterROAS: 4.2,
          conversionIncrease: "85%",
          cpaReduction: "40%"
        }),
        testimonial: "GrowthForge transformed our advertising performance beyond our expectations.",
        featured: true,
        clientLogo: "",
        imagePath: ""
      }
    ];
    
    sampleCaseStudies.forEach(caseStudy => this.createCaseStudy(caseStudy));
    
    // Add sample testimonials
    const sampleTestimonials: InsertTestimonial[] = [
      {
        name: "Priya Sharma",
        position: "CEO",
        company: "TechSolutions India",
        content: "GrowthForge transformed our digital presence completely. Within just 3 months, our lead generation increased by 170% while our cost per acquisition dropped by 40%. Their team is responsive, strategic, and truly invested in our success.",
        featured: true,
        imagePath: ""
      }
    ];
    
    sampleTestimonials.forEach(testimonial => this.createTestimonial(testimonial));
    
    // Add sample blog posts
    const sampleBlogPosts: InsertBlogPost[] = [
      {
        title: "5 Ad Strategies That Doubled Our Clients' ROI",
        slug: "ad-strategies-doubled-roi",
        category: "SEO",
        summary: "Learn the proven techniques that can transform your advertising performance.",
        content: "Detailed content about ad strategies...",
        author: "Marketing Team",
        readTime: 5,
        published: true,
        featured: true,
        imagePath: ""
      },
      {
        title: "How to Use Google Analytics 4 for Actionable Insights",
        slug: "google-analytics-4-actionable-insights",
        category: "Analytics",
        summary: "Master the new GA4 interface and extract valuable data to guide your marketing decisions.",
        content: "Detailed content about GA4...",
        author: "Analytics Team",
        readTime: 7,
        published: true,
        featured: true,
        imagePath: ""
      },
      {
        title: "The Complete Guide to Instagram Marketing in 2023",
        slug: "instagram-marketing-guide-2023",
        category: "Social Media",
        summary: "Stay ahead of algorithm changes and trends to maximize your Instagram performance.",
        content: "Detailed content about Instagram marketing...",
        author: "Social Media Team",
        readTime: 6,
        published: true,
        featured: true,
        imagePath: ""
      }
    ];
    
    sampleBlogPosts.forEach(blogPost => this.createBlogPost(blogPost));
    
    // Add sample job listings
    const sampleJobListings: InsertJobListing[] = [
      {
        title: "SEO Specialist",
        department: "Digital Marketing",
        location: "Bengaluru",
        type: "Full-time",
        description: "We're looking for an experienced SEO specialist to join our team.",
        requirements: "3+ years of experience in SEO, knowledge of latest trends and algorithms.",
        active: true
      },
      {
        title: "Social Media Manager",
        department: "Digital Marketing",
        location: "Remote",
        type: "Full-time",
        description: "Managing social media accounts for various clients.",
        requirements: "2+ years of experience in social media management, creative content creation skills.",
        active: true
      }
    ];
    
    sampleJobListings.forEach(jobListing => this.createJobListing(jobListing));
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Contact form submissions
  async createContactSubmission(submission: InsertContactSubmission): Promise<ContactSubmission> {
    const id = this.currentContactSubmissionId++;
    const createdAt = new Date();
    const contactSubmission: ContactSubmission = { ...submission, id, createdAt };
    this.contactSubmissions.set(id, contactSubmission);
    return contactSubmission;
  }

  async getContactSubmissions(): Promise<ContactSubmission[]> {
    return Array.from(this.contactSubmissions.values());
  }

  // Services
  async getServices(): Promise<Service[]> {
    return Array.from(this.services.values());
  }

  async getServiceById(id: number): Promise<Service | undefined> {
    return this.services.get(id);
  }

  async createService(service: InsertService): Promise<Service> {
    const id = this.currentServiceId++;
    const newService: Service = { ...service, id };
    this.services.set(id, newService);
    return newService;
  }

  // Case studies
  async getCaseStudies(): Promise<CaseStudy[]> {
    return Array.from(this.caseStudies.values());
  }

  async getCaseStudyById(id: number): Promise<CaseStudy | undefined> {
    return this.caseStudies.get(id);
  }

  async getCaseStudiesByIndustry(industry: string): Promise<CaseStudy[]> {
    return Array.from(this.caseStudies.values()).filter(
      (study) => study.industry === industry
    );
  }

  async getFeaturedCaseStudies(): Promise<CaseStudy[]> {
    return Array.from(this.caseStudies.values()).filter(
      (study) => study.featured
    );
  }

  async createCaseStudy(caseStudy: InsertCaseStudy): Promise<CaseStudy> {
    const id = this.currentCaseStudyId++;
    const newCaseStudy: CaseStudy = { ...caseStudy, id };
    this.caseStudies.set(id, newCaseStudy);
    return newCaseStudy;
  }

  // Testimonials
  async getTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonials.values());
  }

  async getFeaturedTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonials.values()).filter(
      (testimonial) => testimonial.featured
    );
  }

  async createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial> {
    const id = this.currentTestimonialId++;
    const newTestimonial: Testimonial = { ...testimonial, id };
    this.testimonials.set(id, newTestimonial);
    return newTestimonial;
  }

  // Blog posts
  async getBlogPosts(): Promise<BlogPost[]> {
    return Array.from(this.blogPosts.values()).filter(
      (post) => post.published
    );
  }

  async getBlogPostById(id: number): Promise<BlogPost | undefined> {
    const post = this.blogPosts.get(id);
    return post && post.published ? post : undefined;
  }

  async getBlogPostBySlug(slug: string): Promise<BlogPost | undefined> {
    const post = Array.from(this.blogPosts.values()).find(
      (post) => post.slug === slug
    );
    return post && post.published ? post : undefined;
  }

  async getBlogPostsByCategory(category: string): Promise<BlogPost[]> {
    return Array.from(this.blogPosts.values()).filter(
      (post) => post.published && post.category === category
    );
  }

  async getFeaturedBlogPosts(): Promise<BlogPost[]> {
    return Array.from(this.blogPosts.values()).filter(
      (post) => post.published && post.featured
    );
  }

  async createBlogPost(blogPost: InsertBlogPost): Promise<BlogPost> {
    const id = this.currentBlogPostId++;
    const createdAt = new Date();
    const newBlogPost: BlogPost = { ...blogPost, id, createdAt };
    this.blogPosts.set(id, newBlogPost);
    return newBlogPost;
  }

  // Job listings
  async getJobListings(): Promise<JobListing[]> {
    return Array.from(this.jobListings.values());
  }

  async getActiveJobListings(): Promise<JobListing[]> {
    return Array.from(this.jobListings.values()).filter(
      (listing) => listing.active
    );
  }

  async getJobListingById(id: number): Promise<JobListing | undefined> {
    return this.jobListings.get(id);
  }

  async createJobListing(jobListing: InsertJobListing): Promise<JobListing> {
    const id = this.currentJobListingId++;
    const createdAt = new Date();
    const newJobListing: JobListing = { ...jobListing, id, createdAt };
    this.jobListings.set(id, newJobListing);
    return newJobListing;
  }
}

export const storage = new MemStorage();
