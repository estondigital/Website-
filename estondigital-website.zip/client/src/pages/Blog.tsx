import { useState } from "react";
import { Helmet } from "react-helmet";
import { useQuery } from "@tanstack/react-query";
import { BlogPost } from "@shared/schema";
import BlogCard from "@/components/blog/BlogCard";
import CategoryFilter from "@/components/blog/CategoryFilter";
import NewsletterSignup from "@/components/blog/NewsletterSignup";

const Blog = () => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  
  const { data: blogPosts, isLoading, error } = useQuery<BlogPost[]>({
    queryKey: ["/api/blog-posts", { category: selectedCategory || undefined }],
  });

  const handleCategoryChange = (category: string | null) => {
    setSelectedCategory(category);
  };

  // Extract unique categories
  const categories = blogPosts 
    ? [...new Set(blogPosts.map(post => post.category))]
    : [];

  // Get featured posts
  const featuredPost = blogPosts?.find(post => post.featured);
  const regularPosts = blogPosts?.filter(post => !post.featured);

  return (
    <>
      <Helmet>
        <title>Blog | GrowthForge - Digital Marketing Agency</title>
        <meta 
          name="description" 
          content="Insights, tips, and strategies for digital marketing success. Stay updated with the latest trends in SEO, social media, PPC, and more."
        />
      </Helmet>

      <main>
        {/* Page Hero */}
        <section className="bg-gradient-to-br from-secondary to-primary/90 text-white pt-16 pb-16 md:pt-20 md:pb-20 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#ffffff_0%,_transparent_70%)] opacity-20"></div>
          </div>
          
          <div className="container mx-auto px-4 md:px-6 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
                Marketing Insights & Resources
              </h1>
              <p className="text-xl mb-6 text-light/90">
                Expert tips, strategies, and industry updates to fuel your digital marketing success
              </p>
            </div>
          </div>
          
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-light dark:from-background to-transparent"></div>
        </section>

        {/* Blog Content */}
        <section className="py-16 bg-light dark:bg-background">
          <div className="container mx-auto px-4 md:px-6">
            {/* Category Filters */}
            <CategoryFilter 
              categories={categories} 
              selectedCategory={selectedCategory} 
              onCategoryChange={handleCategoryChange} 
            />
            
            {isLoading ? (
              <div className="text-center py-12">
                <p>Loading blog posts...</p>
              </div>
            ) : error ? (
              <div className="text-center py-12">
                <p className="text-red-500">Failed to load blog posts. Please try again later.</p>
              </div>
            ) : blogPosts && blogPosts.length > 0 ? (
              <>
                {/* Featured Post */}
                {featuredPost && !selectedCategory && (
                  <div className="mb-12">
                    <h2 className="text-2xl font-bold mb-6 text-secondary dark:text-white">Featured Insight</h2>
                    <div className="bg-white dark:bg-secondary/10 rounded-xl overflow-hidden shadow-md">
                      <div className="md:flex">
                        <div className="md:w-1/2">
                          <img 
                            src={featuredPost.imagePath || "https://images.unsplash.com/photo-1432888498266-38ffec3eaf0a?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400"} 
                            alt={featuredPost.title} 
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="md:w-1/2 p-8">
                          <div className="inline-block px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium mb-4">
                            {featuredPost.category}
                          </div>
                          <h3 className="text-2xl font-bold mb-4 text-secondary dark:text-white">{featuredPost.title}</h3>
                          <p className="text-muted dark:text-muted-foreground mb-6">{featuredPost.summary}</p>
                          <div className="flex items-center mb-6">
                            <p className="text-sm text-muted dark:text-muted-foreground">
                              By <span className="font-medium">{featuredPost.author}</span> • {featuredPost.readTime} min read
                            </p>
                          </div>
                          <a href={`/blog/${featuredPost.slug}`} className="text-primary font-medium flex items-center hover:text-primary/80 transition-all">
                            Read Article <i className="fas fa-arrow-right ml-2 text-sm"></i>
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Regular Posts */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {(selectedCategory ? blogPosts : regularPosts)?.map((post) => (
                    <BlogCard key={post.id} post={post} />
                  ))}
                </div>
              </>
            ) : (
              <div className="text-center py-12">
                <p>No blog posts found for the selected category.</p>
              </div>
            )}
            
            {/* Newsletter Signup */}
            <div className="mt-16">
              <NewsletterSignup />
            </div>
          </div>
        </section>
      </main>
    </>
  );
};

export default Blog;
