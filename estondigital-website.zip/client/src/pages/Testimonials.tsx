import { Helmet } from "react-helmet";
import { useQuery } from "@tanstack/react-query";
import { Testimonial } from "@shared/schema";
import TestimonialCard from "@/components/testimonials/TestimonialCard";
import VideoTestimonial from "@/components/testimonials/VideoTestimonial";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import CTABanner from "@/components/home/CTABanner";

const Testimonials = () => {
  const { data: testimonials, isLoading, error } = useQuery<Testimonial[]>({
    queryKey: ["/api/testimonials"],
  });

  // Mock video testimonials for demonstration
  const videoTestimonials = [
    {
      id: "video1",
      name: "Rahul Mehta",
      position: "CEO",
      company: "TechVentures India",
      thumbnailUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
      videoId: "dQw4w9WgXcQ" // YouTube video ID
    },
    {
      id: "video2",
      name: "Ananya Singh",
      position: "Marketing Director",
      company: "Retail Solutions",
      thumbnailUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
      videoId: "dQw4w9WgXcQ" // YouTube video ID
    }
  ];

  return (
    <>
      <Helmet>
        <title>Testimonials | GrowthForge - Digital Marketing Agency</title>
        <meta 
          name="description" 
          content="Read what our clients have to say about working with GrowthForge. Testimonials and reviews from businesses across various industries."
        />
      </Helmet>

      <main>
        {/* Page Hero */}
        <section className="bg-gradient-to-br from-secondary to-primary/90 text-white pt-16 pb-16 md:pt-20 md:pb-20 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#ffffff_0%,_transparent_70%)] opacity-20"></div>
          </div>
          
          <div className="container mx-auto px-4 md:px-6 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
                Client Testimonials
              </h1>
              <p className="text-xl mb-6 text-light/90">
                Don't take our word for it - hear directly from the businesses we've helped succeed
              </p>
            </div>
          </div>
          
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-light dark:from-background to-transparent"></div>
        </section>

        {/* Testimonials Content */}
        <section className="py-16 bg-light dark:bg-background">
          <div className="container mx-auto px-4 md:px-6">
            <Tabs defaultValue="text" className="max-w-4xl mx-auto">
              <div className="text-center mb-8">
                <TabsList>
                  <TabsTrigger value="text">Text Testimonials</TabsTrigger>
                  <TabsTrigger value="video">Video Testimonials</TabsTrigger>
                  <TabsTrigger value="social">Social Media</TabsTrigger>
                </TabsList>
              </div>
              
              <TabsContent value="text" className="mt-4">
                {isLoading ? (
                  <div className="text-center py-12">
                    <p>Loading testimonials...</p>
                  </div>
                ) : error ? (
                  <div className="text-center py-12">
                    <p className="text-red-500">Failed to load testimonials. Please try again later.</p>
                  </div>
                ) : testimonials && testimonials.length > 0 ? (
                  <div className="space-y-8">
                    {testimonials.map((testimonial) => (
                      <TestimonialCard key={testimonial.id} testimonial={testimonial} />
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <p>No testimonials found.</p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="video" className="mt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {videoTestimonials.map((video) => (
                    <VideoTestimonial key={video.id} video={video} />
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="social" className="mt-4">
                <div className="bg-white dark:bg-secondary/10 p-8 rounded-xl shadow-md text-center">
                  <h3 className="text-xl font-bold mb-6 text-secondary dark:text-white">Social Media Mentions</h3>
                  <p className="text-muted dark:text-muted-foreground mb-6">
                    See what people are saying about us on social media
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                      <div className="flex items-center mb-3">
                        <img 
                          src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50" 
                          alt="Twitter user" 
                          className="w-10 h-10 rounded-full mr-3" 
                        />
                        <div>
                          <p className="font-medium text-secondary dark:text-white">Amit Kumar</p>
                          <p className="text-sm text-muted dark:text-muted-foreground">@amitkumar</p>
                        </div>
                      </div>
                      <p className="text-muted dark:text-muted-foreground text-sm">
                        "Working with @GrowthForge has been a game-changer for our business. 
                        Their SEO strategies have boosted our organic traffic by 150% in just 3 months! 
                        Highly recommended! #DigitalMarketing #SEO"
                      </p>
                    </div>
                    
                    <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                      <div className="flex items-center mb-3">
                        <img 
                          src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50" 
                          alt="LinkedIn user" 
                          className="w-10 h-10 rounded-full mr-3" 
                        />
                        <div>
                          <p className="font-medium text-secondary dark:text-white">Priya Sharma</p>
                          <p className="text-sm text-muted dark:text-muted-foreground">LinkedIn</p>
                        </div>
                      </div>
                      <p className="text-muted dark:text-muted-foreground text-sm">
                        "I want to give a shoutout to GrowthForge for their exceptional 
                        performance marketing services. Their team has helped us achieve a 
                        3.5x ROAS on our campaigns. If you're looking for ROI-focused digital 
                        marketing, they're the ones to call!"
                      </p>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
            
            {/* Star Ratings & Review Snippets */}
            <div className="max-w-4xl mx-auto mt-16 bg-white dark:bg-secondary/10 p-8 rounded-xl shadow-md">
              <h3 className="text-xl font-bold mb-6 text-center text-secondary dark:text-white">Ratings & Reviews</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="flex justify-center text-yellow-400 mb-2">
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                  </div>
                  <p className="font-bold text-secondary dark:text-white">4.9/5</p>
                  <p className="text-sm text-muted dark:text-muted-foreground">on Google (86 reviews)</p>
                </div>
                
                <div className="text-center">
                  <div className="flex justify-center text-yellow-400 mb-2">
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star-half-alt"></i>
                  </div>
                  <p className="font-bold text-secondary dark:text-white">4.8/5</p>
                  <p className="text-sm text-muted dark:text-muted-foreground">on Clutch (32 reviews)</p>
                </div>
                
                <div className="text-center">
                  <div className="flex justify-center text-yellow-400 mb-2">
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                    <i className="fas fa-star"></i>
                  </div>
                  <p className="font-bold text-secondary dark:text-white">5.0/5</p>
                  <p className="text-sm text-muted dark:text-muted-foreground">on Facebook (41 reviews)</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <CTABanner />
      </main>
    </>
  );
};

export default Testimonials;
