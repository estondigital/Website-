import { Helmet } from "react-helmet";
import ContactForm from "@/components/contact/ContactForm";

const Contact = () => {
  return (
    <>
      <Helmet>
        <title>Contact Us | GrowthForge - Digital Marketing Agency</title>
        <meta 
          name="description" 
          content="Get in touch with GrowthForge for your digital marketing needs. Request a consultation, ask questions, or discuss your project with our experts."
        />
      </Helmet>

      <main>
        {/* Page Hero */}
        <section className="bg-gradient-to-br from-secondary to-primary/90 text-white pt-16 pb-16 md:pt-20 md:pb-20 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#ffffff_0%,_transparent_70%)] opacity-20"></div>
          </div>
          
          <div className="container mx-auto px-4 md:px-6 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
                Contact Us
              </h1>
              <p className="text-xl mb-6 text-light/90">
                Let's discuss how we can help your business grow
              </p>
            </div>
          </div>
          
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-light dark:from-background to-transparent"></div>
        </section>

        <ContactForm />

        {/* Map Section */}
        <section className="py-12 bg-white dark:bg-secondary/10">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-2xl font-bold mb-6 text-center text-secondary dark:text-white">Find Us</h2>
              <div className="bg-light dark:bg-secondary/10 rounded-xl overflow-hidden shadow-md">
                <div className="aspect-w-16 aspect-h-9 h-96">
                  <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3887.9988954433186!2d77.596889!3d12.971599!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae1670c9b44e6d%3A0xf8dfc3e8517e4fe0!2sBengaluru%2C%20Karnataka%2C%20India!5e0!3m2!1sen!2sus!4v1650000000000!5m2!1sen!2sus" 
                    width="100%" 
                    height="100%" 
                    style={{ border: 0 }} 
                    allowFullScreen 
                    loading="lazy" 
                    referrerPolicy="no-referrer-when-downgrade"
                    title="GrowthForge Office Location"
                  ></iframe>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Alternate Contact Channels */}
        <section className="py-12 bg-light dark:bg-background">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-4xl mx-auto text-center">
              <h2 className="text-2xl font-bold mb-8 text-secondary dark:text-white">Alternative Ways to Reach Us</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-white dark:bg-secondary/10 p-8 rounded-xl shadow-md text-center">
                  <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
                    <i className="fab fa-whatsapp text-green-500 text-3xl"></i>
                  </div>
                  <h3 className="text-xl font-bold mb-4 text-secondary dark:text-white">WhatsApp</h3>
                  <p className="text-muted dark:text-muted-foreground mb-6">
                    Chat directly with our team for quick inquiries and updates
                  </p>
                  <a 
                    href="https://wa.me/919876543210" 
                    className="inline-flex items-center justify-center gap-2 px-5 py-2 rounded-full bg-green-500 text-white font-medium hover:bg-green-600 transition-colors"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <i className="fab fa-whatsapp"></i>
                    Chat on WhatsApp
                  </a>
                </div>
                
                <div className="bg-white dark:bg-secondary/10 p-8 rounded-xl shadow-md text-center">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                    <i className="fas fa-comments text-primary text-2xl"></i>
                  </div>
                  <h3 className="text-xl font-bold mb-4 text-secondary dark:text-white">Live Chat</h3>
                  <p className="text-muted dark:text-muted-foreground mb-6">
                    Chat with our team directly on our website during business hours
                  </p>
                  <button 
                    className="inline-flex items-center justify-center gap-2 px-5 py-2 rounded-full bg-primary text-white font-medium hover:bg-primary/90 transition-colors"
                  >
                    <i className="fas fa-comment-dots"></i>
                    Start Live Chat
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </>
  );
};

export default Contact;
