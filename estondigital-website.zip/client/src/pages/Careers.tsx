import { Helmet } from "react-helmet";
import { useQuery } from "@tanstack/react-query";
import { JobListing } from "@shared/schema";
import JobListingComponent from "@/components/careers/JobListing";
import TeamCulture from "@/components/careers/TeamCulture";
import HiringProcess from "@/components/careers/HiringProcess";

const Careers = () => {
  const { data: jobListings, isLoading, error } = useQuery<JobListing[]>({
    queryKey: ["/api/job-listings", { active: true }],
  });

  return (
    <>
      <Helmet>
        <title>Careers | GrowthForge - Digital Marketing Agency</title>
        <meta 
          name="description" 
          content="Join our team at GrowthForge. Explore current job openings and discover why we're a great place to work."
        />
      </Helmet>

      <main>
        {/* Page Hero */}
        <section className="bg-gradient-to-br from-secondary to-primary/90 text-white pt-16 pb-16 md:pt-20 md:pb-20 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#ffffff_0%,_transparent_70%)] opacity-20"></div>
          </div>
          
          <div className="container mx-auto px-4 md:px-6 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
                Join Our Team
              </h1>
              <p className="text-xl mb-6 text-light/90">
                Build your career with a team that values innovation, growth, and excellence
              </p>
            </div>
          </div>
          
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-light dark:from-background to-transparent"></div>
        </section>

        {/* Why Work With Us */}
        <section className="py-16 bg-light dark:bg-background">
          <div className="container mx-auto px-4 md:px-6">
            <div className="md:flex items-center gap-12">
              <div className="md:w-1/2 mb-10 md:mb-0">
                <img 
                  src="https://images.unsplash.com/photo-1600880292089-90a7e086ee0c?ixlib=rb-4.0.3&auto=format&fit=crop&w=700&h=500" 
                  alt="Team members collaborating" 
                  className="rounded-xl shadow-md w-full"
                />
              </div>
              
              <div className="md:w-1/2">
                <h2 className="text-3xl md:text-4xl font-bold mb-6 text-secondary dark:text-white">Why Work With Us</h2>
                <p className="text-muted dark:text-muted-foreground mb-6">
                  At GrowthForge, we believe in creating an environment where talented individuals can thrive, 
                  innovate, and grow both personally and professionally. We're committed to fostering a culture 
                  of collaboration, continuous learning, and excellence.
                </p>
                
                <div className="space-y-4 mb-8">
                  <div className="flex items-start">
                    <div className="w-10 h-10 bg-primary/10 dark:bg-primary/20 rounded-full flex items-center justify-center mr-3 mt-1">
                      <i className="fas fa-rocket text-primary"></i>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-1 text-secondary dark:text-white">Career Growth</h3>
                      <p className="text-muted dark:text-muted-foreground">Structured career paths with regular training and skill development opportunities</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="w-10 h-10 bg-primary/10 dark:bg-primary/20 rounded-full flex items-center justify-center mr-3 mt-1">
                      <i className="fas fa-handshake text-primary"></i>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-1 text-secondary dark:text-white">Collaborative Culture</h3>
                      <p className="text-muted dark:text-muted-foreground">Work with talented professionals in a supportive and inclusive environment</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="w-10 h-10 bg-primary/10 dark:bg-primary/20 rounded-full flex items-center justify-center mr-3 mt-1">
                      <i className="fas fa-gift text-primary"></i>
                    </div>
                    <div>
                      <h3 className="font-bold text-lg mb-1 text-secondary dark:text-white">Great Benefits</h3>
                      <p className="text-muted dark:text-muted-foreground">Competitive salary, health insurance, flexible work options, and more</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <TeamCulture />
        <HiringProcess />

        {/* Open Positions */}
        <section className="py-16 bg-white dark:bg-secondary/10">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold mb-8 text-center text-secondary dark:text-white">Open Positions</h2>
              
              {isLoading ? (
                <div className="text-center py-12">
                  <p>Loading job listings...</p>
                </div>
              ) : error ? (
                <div className="text-center py-12">
                  <p className="text-red-500">Failed to load job listings. Please try again later.</p>
                </div>
              ) : jobListings && jobListings.length > 0 ? (
                <div className="space-y-6">
                  {jobListings.map((job) => (
                    <JobListingComponent key={job.id} job={job} />
                  ))}
                </div>
              ) : (
                <div className="bg-light dark:bg-secondary/20 p-8 rounded-xl text-center">
                  <h3 className="text-xl font-bold mb-4 text-secondary dark:text-white">No Open Positions</h3>
                  <p className="text-muted dark:text-muted-foreground mb-6">
                    We don't have any open positions at the moment, but we're always looking for talented individuals to join our team.
                  </p>
                  <p className="text-muted dark:text-muted-foreground">
                    Email your resume to <a href="mailto:careers@growthforge.com" className="text-primary">careers@growthforge.com</a> for future opportunities.
                  </p>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Employee Testimonials */}
        <section className="py-16 bg-light dark:bg-background">
          <div className="container mx-auto px-4 md:px-6">
            <h2 className="text-3xl font-bold mb-8 text-center text-secondary dark:text-white">Team Testimonials</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <div className="bg-white dark:bg-secondary/10 p-6 rounded-xl shadow-md">
                <div className="flex items-center mb-4">
                  <img 
                    src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50" 
                    alt="Employee" 
                    className="w-12 h-12 rounded-full mr-4" 
                  />
                  <div>
                    <h3 className="font-bold text-secondary dark:text-white">Arjun Patel</h3>
                    <p className="text-sm text-muted dark:text-muted-foreground">Senior SEO Specialist, 3 years</p>
                  </div>
                </div>
                <p className="text-muted dark:text-muted-foreground">
                  "Working at GrowthForge has been the highlight of my career. The culture of continuous learning, 
                  supportive colleagues, and challenging projects has helped me grow both professionally and personally."
                </p>
              </div>
              
              <div className="bg-white dark:bg-secondary/10 p-6 rounded-xl shadow-md">
                <div className="flex items-center mb-4">
                  <img 
                    src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50" 
                    alt="Employee" 
                    className="w-12 h-12 rounded-full mr-4" 
                  />
                  <div>
                    <h3 className="font-bold text-secondary dark:text-white">Meera Singh</h3>
                    <p className="text-sm text-muted dark:text-muted-foreground">Performance Marketing Manager, 2 years</p>
                  </div>
                </div>
                <p className="text-muted dark:text-muted-foreground">
                  "The best thing about GrowthForge is how they value work-life balance and employee wellbeing. 
                  I've never felt more supported in my career goals, and the team really feels like family."
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
    </>
  );
};

export default Careers;
