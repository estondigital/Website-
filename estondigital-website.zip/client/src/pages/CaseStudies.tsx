import { useState } from "react";
import { Helmet } from "react-helmet";
import { useQuery } from "@tanstack/react-query";
import { CaseStudy } from "@shared/schema";
import CaseStudyCard from "@/components/case-studies/CaseStudyCard";
import CaseStudyFilters from "@/components/case-studies/CaseStudyFilters";
import CTABanner from "@/components/home/CTABanner";

const CaseStudies = () => {
  const [selectedIndustry, setSelectedIndustry] = useState<string | null>(null);
  
  const { data: caseStudies, isLoading, error } = useQuery<CaseStudy[]>({
    queryKey: ["/api/case-studies", { industry: selectedIndustry || undefined }],
  });

  const handleFilterChange = (industry: string | null) => {
    setSelectedIndustry(industry);
  };

  return (
    <>
      <Helmet>
        <title>Case Studies | GrowthForge - Digital Marketing Agency</title>
        <meta 
          name="description" 
          content="Explore our success stories and case studies. See how we've helped businesses achieve exceptional results through strategic digital marketing."
        />
      </Helmet>

      <main>
        {/* Page Hero */}
        <section className="bg-gradient-to-br from-secondary to-primary/90 text-white pt-16 pb-16 md:pt-20 md:pb-20 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#ffffff_0%,_transparent_70%)] opacity-20"></div>
          </div>
          
          <div className="container mx-auto px-4 md:px-6 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
                Our Success Stories
              </h1>
              <p className="text-xl mb-6 text-light/90">
                Real results for real businesses. Discover how we help our clients succeed.
              </p>
            </div>
          </div>
          
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-light dark:from-background to-transparent"></div>
        </section>

        {/* Case Studies Filters and List */}
        <section className="py-16 bg-light dark:bg-background">
          <div className="container mx-auto px-4 md:px-6">
            <CaseStudyFilters selectedIndustry={selectedIndustry} onFilterChange={handleFilterChange} />
            
            {isLoading ? (
              <div className="text-center py-12">
                <p>Loading case studies...</p>
              </div>
            ) : error ? (
              <div className="text-center py-12">
                <p className="text-red-500">Failed to load case studies. Please try again later.</p>
              </div>
            ) : caseStudies && caseStudies.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-8">
                {caseStudies.map((caseStudy) => (
                  <CaseStudyCard key={caseStudy.id} caseStudy={caseStudy} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p>No case studies found for the selected industry.</p>
              </div>
            )}
          </div>
        </section>

        <CTABanner />
      </main>
    </>
  );
};

export default CaseStudies;
