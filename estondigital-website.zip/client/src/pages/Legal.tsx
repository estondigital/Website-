import { useState } from "react";
import { Helmet } from "react-helmet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PrivacyPolicy from "@/components/legal/PrivacyPolicy";
import TermsAndConditions from "@/components/legal/TermsAndConditions";

const Legal = () => {
  return (
    <>
      <Helmet>
        <title>Legal | GrowthForge - Digital Marketing Agency</title>
        <meta 
          name="description" 
          content="Legal information including privacy policy, terms and conditions, and cookie policy for GrowthForge Digital Marketing Agency."
        />
      </Helmet>

      <main>
        {/* Page Hero */}
        <section className="bg-gradient-to-br from-secondary to-primary/90 text-white pt-16 pb-16 md:pt-20 md:pb-20 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#ffffff_0%,_transparent_70%)] opacity-20"></div>
          </div>
          
          <div className="container mx-auto px-4 md:px-6 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
                Legal Information
              </h1>
              <p className="text-xl mb-6 text-light/90">
                Privacy Policy, Terms & Conditions, and Cookie Policy
              </p>
            </div>
          </div>
          
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-light dark:from-background to-transparent"></div>
        </section>

        {/* Legal Content */}
        <section className="py-16 bg-light dark:bg-background">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-4xl mx-auto">
              <Tabs defaultValue="privacy" className="mb-12">
                <div className="text-center mb-8">
                  <TabsList>
                    <TabsTrigger value="privacy">Privacy Policy</TabsTrigger>
                    <TabsTrigger value="terms">Terms & Conditions</TabsTrigger>
                    <TabsTrigger value="cookies">Cookie Policy</TabsTrigger>
                  </TabsList>
                </div>
                
                <TabsContent value="privacy">
                  <div className="bg-white dark:bg-secondary/10 p-8 rounded-xl shadow-md">
                    <PrivacyPolicy />
                  </div>
                </TabsContent>
                
                <TabsContent value="terms">
                  <div className="bg-white dark:bg-secondary/10 p-8 rounded-xl shadow-md">
                    <TermsAndConditions />
                  </div>
                </TabsContent>
                
                <TabsContent value="cookies">
                  <div className="bg-white dark:bg-secondary/10 p-8 rounded-xl shadow-md">
                    <h2 className="text-2xl font-bold mb-6 text-secondary dark:text-white">Cookie Policy</h2>
                    
                    <div className="prose dark:prose-invert max-w-none">
                      <h3>What Are Cookies</h3>
                      <p>
                        Cookies are small pieces of data stored on your device (computer or mobile device) when you visit a website. 
                        They are widely used to make websites work more efficiently and provide information to the owners of the site.
                      </p>
                      
                      <h3>How We Use Cookies</h3>
                      <p>We use cookies for the following purposes:</p>
                      <ul>
                        <li>To enable certain functions of the website</li>
                        <li>To provide analytics and understand how you use our website</li>
                        <li>To store your preferences</li>
                        <li>To enable advertisements delivery, including behavioral advertising</li>
                      </ul>
                      
                      <h3>Types of Cookies We Use</h3>
                      <p>Our website uses the following types of cookies:</p>
                      
                      <h4>Essential Cookies</h4>
                      <p>
                        These cookies are essential for the operation of our website. They include cookies that enable you to log into secure areas, 
                        use a shopping cart, or make use of e-billing services.
                      </p>
                      
                      <h4>Analytical/Performance Cookies</h4>
                      <p>
                        These allow us to recognize and count the number of visitors and to see how visitors move around our website when they are 
                        using it. This helps us to improve the way our website works, for example, by ensuring that users are finding what they are 
                        looking for easily.
                      </p>
                      
                      <h4>Functionality Cookies</h4>
                      <p>
                        These are used to recognize you when you return to our website. This enables us to personalize our content for you, 
                        greet you by name and remember your preferences.
                      </p>
                      
                      <h4>Targeting/Advertising Cookies</h4>
                      <p>
                        These cookies record your visit to our website, the pages you have visited and the links you have followed. 
                        We will use this information to make our website and the advertising displayed on it more relevant to your interests.
                      </p>
                      
                      <h3>Your Choices Regarding Cookies</h3>
                      <p>
                        You can set your browser to refuse all or some browser cookies, or to alert you when websites set or access cookies. 
                        If you disable or refuse cookies, please note that some parts of this website may become inaccessible or not function properly.
                      </p>
                      
                      <h3>More Information</h3>
                      <p>
                        If you would like more information about cookies and how to manage them, please contact us at privacy@growthforge.com.
                      </p>
                      
                      <p>This Cookie Policy was last updated on April 15, 2023.</p>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
              
              <div className="text-center">
                <p className="text-muted dark:text-muted-foreground">
                  If you have any questions about our legal policies, please <a href="/contact" className="text-primary">contact us</a>.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
    </>
  );
};

export default Legal;
