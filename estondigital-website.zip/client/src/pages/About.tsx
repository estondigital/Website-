import { Helmet } from "react-helmet";
import StorySection from "@/components/about/StorySection";
import CoreValues from "@/components/about/CoreValues";
import TeamSection from "@/components/about/TeamSection";
import Awards from "@/components/about/Awards";
import CTABanner from "@/components/home/CTABanner";

const About = () => {
  return (
    <>
      <Helmet>
        <title>About Us | Eston Digital - Digital Marketing Agency</title>
        <meta 
          name="description" 
          content="Learn about Eston Digital, India's premier digital marketing agency. Our story, values, leadership team, and what makes us different."
        />
      </Helmet>

      <main>
        {/* Page Hero */}
        <section className="bg-gradient-to-br from-secondary to-primary/90 text-white pt-16 pb-16 md:pt-20 md:pb-20 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#ffffff_0%,_transparent_70%)] opacity-20"></div>
          </div>
          
          <div className="container mx-auto px-4 md:px-6 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
                About Eston Digital
              </h1>
              <p className="text-xl mb-6 text-light/90">
                Get to know the team behind India's most results-driven digital marketing agency
              </p>
            </div>
          </div>
          
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-light dark:from-background to-transparent"></div>
        </section>

        <StorySection />
        <CoreValues />
        <TeamSection />
        <Awards />
        <CTABanner />
      </main>
    </>
  );
};

export default About;
