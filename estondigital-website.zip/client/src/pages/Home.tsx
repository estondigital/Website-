import React from "react";
import { Helmet } from "react-helmet";
import HeroSection from "@/components/home/HeroSection";
import ClientLogos from "@/components/home/ClientLogos";
import QuickMetrics from "@/components/home/QuickMetrics";
import ServicesPreview from "@/components/home/ServicesPreview";
import CaseStudyPreview from "@/components/home/CaseStudyPreview";
import TestimonialsPreview from "@/components/home/TestimonialsPreview";
import BlogPreview from "@/components/home/BlogPreview";
import AboutPreview from "@/components/home/AboutPreview";
import CTABanner from "@/components/home/CTABanner";
import ContactForm from "@/components/contact/ContactForm";

const Home = () => {
  return (
    <>
      <Helmet>
        <title>Eston Digital - India's Results-Driven Digital Marketing Agency</title>
        <meta 
          name="description" 
          content="Eston Digital is India's premier ROI-driven digital marketing agency. We help brands scale with data-driven strategies for SEO, PPC, social media, and more."
        />
      </Helmet>
      
      <main>
        <HeroSection />
        <ClientLogos />
        <QuickMetrics />
        <ServicesPreview />
        <CaseStudyPreview />
        <TestimonialsPreview />
        <BlogPreview />
        <AboutPreview />
        <CTABanner />
        <ContactForm />
      </main>
    </>
  );
};

export default Home;
