import { useState } from "react";
import { Helmet } from "react-helmet";
import { useQuery } from "@tanstack/react-query";
import { Service } from "@shared/schema";
import ServiceDetail from "@/components/services/ServiceDetail";
import ProcessOverview from "@/components/services/ProcessOverview";
import CTABanner from "@/components/home/CTABanner";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const Services = () => {
  const { data: services, isLoading, error } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <p>Loading services...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <p className="text-red-500">Failed to load services. Please try again later.</p>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Services | GrowthForge - Digital Marketing Agency</title>
        <meta 
          name="description" 
          content="Explore our comprehensive digital marketing services. SEO, PPC, social media, content marketing, and more tailored to your business needs."
        />
      </Helmet>

      <main>
        {/* Page Hero */}
        <section className="bg-gradient-to-br from-secondary to-primary/90 text-white pt-16 pb-16 md:pt-20 md:pb-20 relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#ffffff_0%,_transparent_70%)] opacity-20"></div>
          </div>
          
          <div className="container mx-auto px-4 md:px-6 relative z-10">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
                360° Digital Marketing Solutions
              </h1>
              <p className="text-xl mb-6 text-light/90">
                Tailored strategies for every stage of growth
              </p>
            </div>
          </div>
          
          <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-light dark:from-background to-transparent"></div>
        </section>

        {/* Services Introduction */}
        <section className="py-16 bg-light dark:bg-background">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-secondary dark:text-white">Our Services</h2>
              <p className="text-muted dark:text-muted-foreground">
                We offer a comprehensive suite of digital marketing services to help your business 
                thrive in the digital landscape. Each service is tailored to your specific needs and 
                business goals.
              </p>
            </div>

            <div className="space-y-12">
              {services?.map((service) => (
                <ServiceDetail key={service.id} service={service} />
              ))}
            </div>
          </div>
        </section>

        {/* Why Choose Us */}
        <section className="py-16 bg-white dark:bg-secondary/10">
          <div className="container mx-auto px-4 md:px-6">
            <div className="max-w-3xl mx-auto text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-secondary dark:text-white">Why Choose Us</h2>
              <p className="text-muted dark:text-muted-foreground">
                We're not just another digital marketing agency. Here's what sets us apart:
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-light dark:bg-secondary/10 p-8 rounded-xl shadow-md text-center">
                <div className="w-16 h-16 bg-primary/10 dark:bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <i className="fas fa-chart-line text-primary text-2xl"></i>
                </div>
                <h3 className="text-xl font-bold mb-4 text-secondary dark:text-white">Proven ROI</h3>
                <p className="text-muted dark:text-muted-foreground">
                  Our strategies are built around delivering measurable return on investment that impacts your bottom line.
                </p>
              </div>

              <div className="bg-light dark:bg-secondary/10 p-8 rounded-xl shadow-md text-center">
                <div className="w-16 h-16 bg-primary/10 dark:bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <i className="fas fa-cogs text-primary text-2xl"></i>
                </div>
                <h3 className="text-xl font-bold mb-4 text-secondary dark:text-white">Custom Strategy</h3>
                <p className="text-muted dark:text-muted-foreground">
                  We develop tailored strategies based on thorough research, competitor analysis, and your unique business goals.
                </p>
              </div>

              <div className="bg-light dark:bg-secondary/10 p-8 rounded-xl shadow-md text-center">
                <div className="w-16 h-16 bg-primary/10 dark:bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <i className="fas fa-user-tie text-primary text-2xl"></i>
                </div>
                <h3 className="text-xl font-bold mb-4 text-secondary dark:text-white">Dedicated Account Manager</h3>
                <p className="text-muted dark:text-muted-foreground">
                  Each client gets a dedicated account manager who ensures smooth communication and project delivery.
                </p>
              </div>
            </div>
          </div>
        </section>

        <ProcessOverview />

        {/* CTA Banner - Not sure what you need */}
        <section className="py-16 bg-gradient-to-r from-secondary/90 to-primary/80 text-white">
          <div className="container mx-auto px-4 md:px-6 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Not Sure What You Need?</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Let's have a conversation about your business goals and how we can help you achieve them.
            </p>
            <Button
              size="lg"
              className="bg-accent hover:bg-accent/90 text-white rounded-full font-bold text-lg px-10"
              asChild
            >
              <Link href="/contact">
                Schedule Free Consultation
              </Link>
            </Button>
          </div>
        </section>
      </main>
    </>
  );
};

export default Services;
