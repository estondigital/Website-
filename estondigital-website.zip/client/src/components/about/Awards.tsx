import { motion } from "framer-motion";
import { awards } from "@/lib/data";

const Awards = () => {
  return (
    <section className="py-16 bg-light dark:bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-secondary dark:text-white">Awards & Recognition</h2>
          <p className="text-muted dark:text-muted-foreground">
            Our commitment to excellence has been recognized by the industry
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {awards.map((award, index) => (
            <motion.div 
              key={award.id}
              className="bg-white dark:bg-secondary/10 rounded-xl p-6 shadow-md text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="bg-primary/10 dark:bg-primary/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="fas fa-trophy text-primary text-2xl"></i>
              </div>
              <h3 className="text-lg font-bold mb-2 text-secondary dark:text-white">{award.title}</h3>
              <p className="text-primary font-medium mb-1">{award.organization}</p>
              <p className="text-muted dark:text-muted-foreground text-sm">{award.year}</p>
            </motion.div>
          ))}
        </div>
        
        {/* Press Mentions */}
        <div className="mt-16">
          <h3 className="text-2xl font-bold mb-8 text-center text-secondary dark:text-white">Featured In</h3>
          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-12">
            <div className="grayscale hover:grayscale-0 opacity-70 hover:opacity-100 transition-all">
              <div className="h-12 w-40 bg-gray-200 dark:bg-gray-700 rounded flex items-center justify-center">
                <span className="text-muted dark:text-white/70 font-medium">Economic Times</span>
              </div>
            </div>
            <div className="grayscale hover:grayscale-0 opacity-70 hover:opacity-100 transition-all">
              <div className="h-12 w-40 bg-gray-200 dark:bg-gray-700 rounded flex items-center justify-center">
                <span className="text-muted dark:text-white/70 font-medium">YourStory</span>
              </div>
            </div>
            <div className="grayscale hover:grayscale-0 opacity-70 hover:opacity-100 transition-all">
              <div className="h-12 w-40 bg-gray-200 dark:bg-gray-700 rounded flex items-center justify-center">
                <span className="text-muted dark:text-white/70 font-medium">Forbes India</span>
              </div>
            </div>
            <div className="grayscale hover:grayscale-0 opacity-70 hover:opacity-100 transition-all">
              <div className="h-12 w-40 bg-gray-200 dark:bg-gray-700 rounded flex items-center justify-center">
                <span className="text-muted dark:text-white/70 font-medium">Business Standard</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Awards;
