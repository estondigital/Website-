import { motion } from "framer-motion";

const StorySection = () => {
  return (
    <section className="py-16 bg-white dark:bg-secondary/10">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-4xl mx-auto">
          <div className="md:flex items-center gap-12">
            <motion.div 
              className="md:w-1/2 mb-10 md:mb-0"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <img 
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&auto=format&fit=crop&w=700&h=500" 
                alt="Our team celebrating a milestone" 
                className="rounded-xl shadow-md w-full"
              />
            </motion.div>
            
            <motion.div 
              className="md:w-1/2"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-secondary dark:text-white">Our Story</h2>
              <p className="text-muted dark:text-muted-foreground mb-6">
                Eston Digital was founded in 2015 with a simple mission: to help businesses achieve tangible growth 
                through data-driven digital marketing strategies.
              </p>
              <p className="text-muted dark:text-muted-foreground mb-6">
                Our founder, Vikram Sharma, experienced firsthand the frustration of working with marketing agencies 
                that focused on vanity metrics rather than business results. He envisioned an agency that would 
                prioritize ROI and measurable outcomes above all else.
              </p>
              <p className="text-muted dark:text-muted-foreground mb-6">
                Starting with just three team members and a handful of clients, we've grown to a team of 50+ digital 
                marketing experts serving over 200 clients across India and beyond.
              </p>
              <div className="bg-primary/10 dark:bg-primary/20 p-4 rounded-lg">
                <h3 className="font-bold text-lg mb-2 text-secondary dark:text-white">Our Mission</h3>
                <p className="text-muted dark:text-muted-foreground italic">
                  "To empower businesses with digital marketing strategies that deliver measurable growth and exceptional ROI."
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default StorySection;
