import { motion } from "framer-motion";
import { coreValues } from "@/lib/data";
import { 
  ShieldCheck, 
  BarChart2, 
  Lightbulb, 
  Users
} from "lucide-react";

const CoreValues = () => {
  // Map icon strings to Lucide React components
  const iconMap: Record<string, React.ReactNode> = {
    "shield-check": <ShieldCheck className="h-12 w-12 text-primary" />,
    "bar-chart-2": <BarChart2 className="h-12 w-12 text-primary" />,
    "lightbulb": <Lightbulb className="h-12 w-12 text-primary" />,
    "users": <Users className="h-12 w-12 text-primary" />
  };

  return (
    <section className="py-16 bg-light dark:bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-secondary dark:text-white">Our Core Values</h2>
          <p className="text-muted dark:text-muted-foreground">
            The principles that guide everything we do
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {coreValues.map((value, index) => (
            <motion.div 
              key={value.id}
              className="bg-white dark:bg-secondary/10 rounded-xl p-6 shadow-md text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="bg-primary/10 dark:bg-primary/20 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
                {iconMap[value.icon]}
              </div>
              <h3 className="text-xl font-bold mb-3 text-secondary dark:text-white">{value.title}</h3>
              <p className="text-muted dark:text-muted-foreground">{value.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CoreValues;
