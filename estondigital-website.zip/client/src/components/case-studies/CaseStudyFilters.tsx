import { useState, useEffect } from "react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import { CaseStudy } from "@shared/schema";

interface CaseStudyFiltersProps {
  selectedIndustry: string | null;
  onFilterChange: (industry: string | null) => void;
}

const CaseStudyFilters = ({ selectedIndustry, onFilterChange }: CaseStudyFiltersProps) => {
  const [industries, setIndustries] = useState<string[]>([]);

  // Get all case studies to extract unique industries
  const { data: caseStudies } = useQuery<CaseStudy[]>({
    queryKey: ["/api/case-studies"],
  });

  useEffect(() => {
    if (caseStudies) {
      // Extract unique industries
      const uniqueIndustries = [...new Set(caseStudies.map(study => study.industry))];
      setIndustries(uniqueIndustries);
    }
  }, [caseStudies]);

  const handleIndustryChange = (value: string) => {
    if (value === "all") {
      onFilterChange(null);
    } else {
      onFilterChange(value);
    }
  };

  if (!industries.length) {
    // Use default industries if none are found
    const defaultIndustries = ["Ecommerce", "SaaS", "Real Estate", "Healthcare"];
    
    return (
      <div className="mb-8">
        <h3 className="text-lg font-medium mb-4 text-center text-secondary dark:text-white">Filter by Industry</h3>
        <Tabs defaultValue={selectedIndustry || "all"} onValueChange={handleIndustryChange} className="w-full">
          <TabsList className="w-full flex justify-center flex-wrap">
            <TabsTrigger value="all">All Industries</TabsTrigger>
            {defaultIndustries.map(industry => (
              <TabsTrigger key={industry} value={industry}>
                {industry}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </div>
    );
  }

  return (
    <div className="mb-8">
      <h3 className="text-lg font-medium mb-4 text-center text-secondary dark:text-white">Filter by Industry</h3>
      <Tabs defaultValue={selectedIndustry || "all"} onValueChange={handleIndustryChange} className="w-full">
        <TabsList className="w-full flex justify-center flex-wrap">
          <TabsTrigger value="all">All Industries</TabsTrigger>
          {industries.map(industry => (
            <TabsTrigger key={industry} value={industry}>
              {industry}
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>
    </div>
  );
};

export default CaseStudyFilters;
