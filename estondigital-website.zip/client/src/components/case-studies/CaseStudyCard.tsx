import { motion } from "framer-motion";
import { CaseStudy } from "@shared/schema";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface CaseStudyCardProps {
  caseStudy: CaseStudy;
}

const CaseStudyCard = ({ caseStudy }: CaseStudyCardProps) => {
  // Parse results if it's a string
  const results = typeof caseStudy.results === 'string' 
    ? JSON.parse(caseStudy.results) 
    : caseStudy.results;
  
  // Function to get a random image if none is provided
  const getRandomImage = () => {
    const imageIds = [
      "photo-1460925895917-afdab827c52f",
      "photo-1551288049-bebda4e38f71",
      "photo-1611162616475-46b635cb6868",
      "photo-1504868584819-f8e8b4b6d7e3"
    ];
    const randomId = imageIds[Math.floor(Math.random() * imageIds.length)];
    return `https://images.unsplash.com/${randomId}?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
    >
      <Card className="overflow-hidden h-full">
        <div className="h-48 overflow-hidden">
          <img 
            src={caseStudy.imagePath || getRandomImage()} 
            alt={caseStudy.title} 
            className="w-full h-full object-cover"
          />
        </div>
        <CardHeader className="pb-2">
          <div className="bg-primary/10 dark:bg-primary/20 px-3 py-1 rounded-full text-primary text-sm font-medium inline-block mb-2">
            {caseStudy.industry}
          </div>
          <h3 className="text-xl font-bold text-secondary dark:text-white">{caseStudy.title}</h3>
          <p className="text-muted dark:text-muted-foreground text-sm">Client: {caseStudy.client}</p>
        </CardHeader>
        <CardContent>
          <p className="text-muted dark:text-muted-foreground mb-4">{caseStudy.description}</p>
          
          <div className="mb-4">
            <h4 className="font-medium mb-2 text-secondary dark:text-white">Key Results:</h4>
            <ul className="space-y-1">
              {Object.entries(results).map(([key, value], index) => {
                // Convert camelCase to readable text
                const readableKey = key
                  .replace(/([A-Z])/g, ' $1')
                  .replace(/^./, (str) => str.toUpperCase())
                  .replace(/([A-Z])\s/g, '$1');
                
                return (
                  <li key={index} className="text-sm text-muted dark:text-muted-foreground">
                    <span className="font-medium">{readableKey}:</span> {value}
                  </li>
                );
              })}
            </ul>
          </div>
          
          {caseStudy.testimonial && (
            <div className="italic text-sm text-muted dark:text-muted-foreground mb-4">
              "{caseStudy.testimonial}"
            </div>
          )}
          
          <Button asChild variant="outline" className="w-full">
            <Link href={`/case-studies/${caseStudy.id}`}>
              View Full Case Study
            </Link>
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default CaseStudyCard;
