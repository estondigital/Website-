import { motion } from "framer-motion";
import { Service } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface ServiceDetailProps {
  service: Service;
}

const iconMap: Record<string, string> = {
  "search": "fas fa-search",
  "chart-line": "fas fa-chart-line",
  "paint-brush": "fas fa-paint-brush",
  "envelope": "fas fa-envelope",
  "video": "fas fa-video",
  "globe": "fas fa-globe",
};

// Mock service deliverables by service type
const serviceDeliverables: Record<string, string[]> = {
  "SEO Optimization": [
    "Comprehensive SEO audit",
    "Keyword research and strategy",
    "On-page SEO optimization",
    "Content creation and optimization",
    "Technical SEO implementation",
    "Link building and outreach",
    "Monthly performance reporting"
  ],
  "Performance Marketing": [
    "Campaign strategy development",
    "Ad creative and copy creation",
    "Audience targeting and segmentation",
    "Campaign setup and optimization",
    "A/B testing of ad elements",
    "Conversion tracking implementation",
    "Weekly and monthly performance reports"
  ],
  "Branding": [
    "Brand identity development",
    "Logo and visual assets creation",
    "Brand messaging and positioning",
    "Brand guidelines documentation",
    "Brand voice and tone development",
    "Social media branding",
    "Brand consistency audit"
  ],
  "Email Marketing": [
    "Email strategy development",
    "Template design and creation",
    "Automation workflow setup",
    "Audience segmentation",
    "A/B testing of subject lines and content",
    "Campaign optimization",
    "Performance analytics and reporting"
  ],
  "Video Production": [
    "Concept development and scripting",
    "Pre-production planning",
    "Professional filming and direction",
    "Video editing and post-production",
    "Animation and motion graphics",
    "Distribution strategy",
    "Performance tracking"
  ],
  "Social Media Management": [
    "Social media strategy development",
    "Content calendar creation",
    "Original content creation",
    "Community management",
    "Platform-specific optimization",
    "Engagement monitoring and response",
    "Analytics and reporting"
  ]
};

const ServiceDetail = ({ service }: ServiceDetailProps) => {
  // Get service deliverables based on service title or provide a default list
  const deliverables = serviceDeliverables[service.title] || [
    "Strategy development",
    "Implementation and execution",
    "Optimization and refinement",
    "Regular reporting and insights",
    "Dedicated account management"
  ];

  return (
    <motion.div 
      id={service.id.toString()}
      className="bg-white dark:bg-secondary/10 rounded-xl shadow-md overflow-hidden"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
    >
      <div className="md:flex">
        <div className="md:w-1/3 bg-primary/5 dark:bg-primary/10 p-8 flex flex-col justify-center">
          <div className="w-16 h-16 bg-primary/10 dark:bg-primary/20 rounded-full flex items-center justify-center mb-6">
            <i className={`${iconMap[service.icon] || 'fas fa-star'} text-primary text-2xl`}></i>
          </div>
          <h3 className="text-2xl font-bold mb-4 text-secondary dark:text-white">{service.title}</h3>
          <p className="text-muted dark:text-muted-foreground mb-8">{service.description}</p>
          <div className="mt-auto">
            <Button asChild className="rounded-full">
              <Link href={`/contact?service=${service.id}`}>
                Request Quote
              </Link>
            </Button>
          </div>
        </div>
        
        <div className="md:w-2/3 p-8">
          <h4 className="text-xl font-bold mb-6 text-secondary dark:text-white">Key Deliverables</h4>
          <ul className="space-y-3">
            {deliverables.map((item, index) => (
              <li key={index} className="flex items-start">
                <div className="w-6 h-6 bg-primary/10 dark:bg-primary/20 rounded-full flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">
                  <i className="fas fa-check text-primary text-xs"></i>
                </div>
                <span className="text-muted dark:text-muted-foreground">{item}</span>
              </li>
            ))}
          </ul>
          
          {/* Service specific CTA */}
          <div className="mt-8 p-4 bg-primary/5 dark:bg-primary/10 rounded-lg">
            <h5 className="font-bold mb-2 text-secondary dark:text-white">Why Choose Our {service.title} Service?</h5>
            <p className="text-muted dark:text-muted-foreground text-sm mb-4">
              We combine industry expertise, data-driven methodology, and creative excellence to deliver 
              {service.title.toLowerCase()} solutions that drive tangible business results.
            </p>
            <Button variant="outline" asChild className="text-primary border-primary hover:bg-primary/10">
              <Link href={`/contact?service=${service.id}`}>
                Learn More <i className="fas fa-arrow-right ml-2 text-sm"></i>
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default ServiceDetail;
