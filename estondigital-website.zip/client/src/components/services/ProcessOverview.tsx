import { motion } from "framer-motion";
import { processSteps } from "@/lib/data";

const ProcessOverview = () => {
  return (
    <section className="py-16 bg-light dark:bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-secondary dark:text-white">Our Process</h2>
          <p className="text-muted dark:text-muted-foreground">
            How we work with you to deliver exceptional results
          </p>
        </div>
        
        <div className="relative max-w-4xl mx-auto">
          {/* Connection line */}
          <div className="absolute left-1/2 top-10 bottom-10 w-1 bg-primary/20 -translate-x-1/2 hidden md:block"></div>
          
          {processSteps.map((step, index) => (
            <motion.div 
              key={step.id} 
              className={`flex flex-col md:flex-row md:items-center mb-12 md:mb-0 ${
                index % 2 === 0 ? "md:text-right md:flex-row-reverse" : ""
              }`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className={`md:w-1/2 mb-4 md:mb-0 ${
                index % 2 === 0 ? "md:pl-12" : "md:pr-12"
              }`}>
                <div className="bg-white dark:bg-secondary/10 p-6 rounded-xl shadow-md">
                  <h3 className="text-xl font-bold mb-2 text-secondary dark:text-white">{step.title}</h3>
                  <p className="text-muted dark:text-muted-foreground">{step.description}</p>
                </div>
              </div>
              
              <div className="flex md:justify-center relative z-10">
                <div className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center font-bold text-lg">
                  {step.id}
                </div>
              </div>
              
              <div className="md:w-1/2"></div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProcessOverview;
