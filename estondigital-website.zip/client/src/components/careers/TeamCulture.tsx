import { motion } from "framer-motion";

const TeamCulture = () => {
  return (
    <section className="py-16 bg-white dark:bg-secondary/10">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-secondary dark:text-white">Culture & Behind-the-Scenes</h2>
          <p className="text-muted dark:text-muted-foreground">
            Get a glimpse of what it's like to be part of the GrowthForge family
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <motion.div 
            className="rounded-xl overflow-hidden shadow-md"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <img 
              src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Team brainstorming session" 
              className="w-full h-64 object-cover"
            />
            <div className="p-4 bg-white dark:bg-secondary/10">
              <h3 className="font-bold text-secondary dark:text-white">Collaborative Brainstorming</h3>
              <p className="text-sm text-muted dark:text-muted-foreground">Weekly strategy sessions where great ideas come to life</p>
            </div>
          </motion.div>
          
          <motion.div 
            className="rounded-xl overflow-hidden shadow-md"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <img 
              src="https://images.unsplash.com/photo-1515187029135-18ee286d815b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Team celebratory dinner" 
              className="w-full h-64 object-cover"
            />
            <div className="p-4 bg-white dark:bg-secondary/10">
              <h3 className="font-bold text-secondary dark:text-white">Celebrating Wins Together</h3>
              <p className="text-sm text-muted dark:text-muted-foreground">Monthly team dinners to celebrate achievements</p>
            </div>
          </motion.div>
          
          <motion.div 
            className="rounded-xl overflow-hidden shadow-md"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <img 
              src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Team building activity" 
              className="w-full h-64 object-cover"
            />
            <div className="p-4 bg-white dark:bg-secondary/10">
              <h3 className="font-bold text-secondary dark:text-white">Team Building Adventures</h3>
              <p className="text-sm text-muted dark:text-muted-foreground">Quarterly outings to strengthen team bonds</p>
            </div>
          </motion.div>
          
          <motion.div 
            className="rounded-xl overflow-hidden shadow-md"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <img 
              src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Modern office space" 
              className="w-full h-64 object-cover"
            />
            <div className="p-4 bg-white dark:bg-secondary/10">
              <h3 className="font-bold text-secondary dark:text-white">Creative Workspace</h3>
              <p className="text-sm text-muted dark:text-muted-foreground">Our open-plan office designed for collaboration</p>
            </div>
          </motion.div>
          
          <motion.div 
            className="rounded-xl overflow-hidden shadow-md"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <img 
              src="https://images.unsplash.com/photo-1507537297725-24a1c029d3ca?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Learning session" 
              className="w-full h-64 object-cover"
            />
            <div className="p-4 bg-white dark:bg-secondary/10">
              <h3 className="font-bold text-secondary dark:text-white">Learning & Development</h3>
              <p className="text-sm text-muted dark:text-muted-foreground">Regular workshops and training sessions</p>
            </div>
          </motion.div>
          
          <motion.div 
            className="rounded-xl overflow-hidden shadow-md"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.5 }}
          >
            <img 
              src="https://images.unsplash.com/photo-1630395822970-acd6a28292fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Cultural celebrations" 
              className="w-full h-64 object-cover"
            />
            <div className="p-4 bg-white dark:bg-secondary/10">
              <h3 className="font-bold text-secondary dark:text-white">Cultural Celebrations</h3>
              <p className="text-sm text-muted dark:text-muted-foreground">Celebrating festivals and special occasions together</p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default TeamCulture;
