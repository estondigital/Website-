import { motion } from "framer-motion";
import { hiringSteps } from "@/lib/data";
import { 
  FileText, 
  Phone, 
  Clipboard, 
  Users, 
  CheckCircle 
} from "lucide-react";

const HiringProcess = () => {
  // Map icon strings to Lucide React components
  const iconMap: Record<string, React.ReactNode> = {
    "file-text": <FileText className="h-8 w-8 text-primary" />,
    "phone": <Phone className="h-8 w-8 text-primary" />,
    "clipboard": <Clipboard className="h-8 w-8 text-primary" />,
    "users": <Users className="h-8 w-8 text-primary" />,
    "check-circle": <CheckCircle className="h-8 w-8 text-primary" />
  };

  return (
    <section className="py-16 bg-light dark:bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-secondary dark:text-white">Our Hiring Process</h2>
          <p className="text-muted dark:text-muted-foreground">
            What to expect when you apply to join our team
          </p>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="relative">
            {/* Connecting line */}
            <div className="absolute left-16 top-0 bottom-0 w-1 bg-primary/20 hidden md:block"></div>
            
            {hiringSteps.map((step, index) => (
              <motion.div 
                key={step.id} 
                className="flex mb-10 last:mb-0 relative"
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="bg-primary/10 dark:bg-primary/20 w-12 h-12 rounded-full flex items-center justify-center mr-4 z-10">
                  {iconMap[step.icon]}
                </div>
                <div className="bg-white dark:bg-secondary/10 rounded-xl p-6 shadow-md flex-1">
                  <h3 className="text-xl font-bold mb-2 text-secondary dark:text-white">
                    Step {step.id}: {step.title}
                  </h3>
                  <p className="text-muted dark:text-muted-foreground">
                    {step.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <p className="text-muted dark:text-muted-foreground mb-4">
              Our hiring process typically takes 2-3 weeks from application to offer.
            </p>
            <p className="text-muted dark:text-muted-foreground">
              Have questions about our hiring process? Email us at <a href="mailto:careers@estondigital.com" className="text-primary">careers@estondigital.com</a>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HiringProcess;
