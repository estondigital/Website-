import { useState } from "react";
import { motion } from "framer-motion";
import { JobListing } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

interface JobListingProps {
  job: JobListing;
}

const JobListingComponent = ({ job }: JobListingProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="bg-white dark:bg-secondary/10 rounded-xl shadow-md overflow-hidden"
    >
      <Accordion type="single" collapsible>
        <AccordionItem value={`job-${job.id}`} className="border-none">
          <div className="p-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div>
                <div className="inline-block px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium mb-2">
                  {job.department}
                </div>
                <h3 className="text-xl font-bold text-secondary dark:text-white">{job.title}</h3>
                <div className="flex items-center mt-2 text-sm text-muted dark:text-muted-foreground">
                  <span className="flex items-center">
                    <i className="fas fa-map-marker-alt mr-2"></i> {job.location}
                  </span>
                  <span className="mx-3">•</span>
                  <span className="flex items-center">
                    <i className="fas fa-briefcase mr-2"></i> {job.type}
                  </span>
                </div>
              </div>
              
              <AccordionTrigger className="mt-4 md:mt-0 py-0 [&[data-state=open]>div>svg]:rotate-180">
                <div className="flex items-center text-primary font-medium">
                  View Details
                  <svg 
                    width="24" 
                    height="24" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-4 w-4 ml-1 transition-transform duration-200"
                  >
                    <path 
                      d="M6 9L12 15L18 9" 
                      stroke="currentColor" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
              </AccordionTrigger>
            </div>
          </div>
          
          <AccordionContent className="pb-6 px-6">
            <div className="mb-6">
              <h4 className="font-bold mb-3 text-secondary dark:text-white">Job Description</h4>
              <p className="text-muted dark:text-muted-foreground whitespace-pre-line">
                {job.description}
              </p>
            </div>
            
            <div className="mb-6">
              <h4 className="font-bold mb-3 text-secondary dark:text-white">Requirements</h4>
              <p className="text-muted dark:text-muted-foreground whitespace-pre-line">
                {job.requirements}
              </p>
            </div>
            
            <Button asChild className="mt-2">
              <a href={`mailto:careers@estondigital.com?subject=Application for ${job.title} Position`}>
                Apply Now
              </a>
            </Button>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </motion.div>
  );
};

export default JobListingComponent;
