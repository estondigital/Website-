import { motion } from "framer-motion";
import { Testimonial } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";

interface TestimonialCardProps {
  testimonial: Testimonial;
}

const TestimonialCard = ({ testimonial }: TestimonialCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
    >
      <Card className="relative overflow-hidden">
        <div className="absolute top-4 left-4 text-5xl text-primary/20 leading-none">
          <i className="fas fa-quote-left"></i>
        </div>
        
        <CardContent className="pt-10 pb-6">
          <p className="text-lg italic text-dark/90 dark:text-white/90 mb-6">
            "{testimonial.content}"
          </p>
          
          <div className="flex items-center">
            <div className="w-14 h-14 rounded-full overflow-hidden mr-4">
              {testimonial.imagePath ? (
                <img 
                  src={testimonial.imagePath} 
                  alt={testimonial.name} 
                  className="w-full h-full object-cover" 
                />
              ) : (
                <img 
                  src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100" 
                  alt="Testimonial author" 
                  className="w-full h-full object-cover" 
                />
              )}
            </div>
            <div>
              <h4 className="font-bold text-secondary dark:text-white">{testimonial.name}</h4>
              <p className="text-muted dark:text-muted-foreground text-sm">{testimonial.position}, {testimonial.company}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default TestimonialCard;
