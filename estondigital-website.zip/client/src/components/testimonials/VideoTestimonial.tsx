import { useState } from "react";
import { VideoTestimonial as VideoTestimonialType } from "@/lib/data";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";

interface VideoTestimonialProps {
  video: VideoTestimonialType;
}

const VideoTestimonial = ({ video }: VideoTestimonialProps) => {
  const [playing, setPlaying] = useState(false);

  const handlePlay = () => {
    setPlaying(true);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
    >
      <Card className="overflow-hidden">
        <div className="relative">
          {!playing ? (
            <div className="relative">
              <img 
                src={video.thumbnailUrl} 
                alt={`${video.name} testimonial video`} 
                className="w-full h-48 object-cover"
              />
              <div 
                className="absolute inset-0 bg-black/50 flex items-center justify-center cursor-pointer"
                onClick={handlePlay}
              >
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center">
                  <i className="fas fa-play text-white text-xl"></i>
                </div>
              </div>
            </div>
          ) : (
            <div className="aspect-video h-48">
              <iframe
                src={`https://www.youtube.com/embed/${video.videoId}?autoplay=1`}
                title={`${video.name} testimonial video`}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="w-full h-full"
              ></iframe>
            </div>
          )}
        </div>
        
        <CardContent className="p-4">
          <h3 className="font-bold text-lg mb-1 text-secondary dark:text-white">{video.name}</h3>
          <p className="text-muted dark:text-muted-foreground text-sm">{video.position}, {video.company}</p>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default VideoTestimonial;
