import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { BlogPost } from "@shared/schema";
import { motion } from "framer-motion";

const BlogPreview = () => {
  const { data: blogPosts, isLoading, error } = useQuery<BlogPost[]>({
    queryKey: ["/api/blog-posts", { featured: true }],
  });

  if (isLoading) {
    return (
      <section id="blog" className="py-16 bg-white dark:bg-secondary/10">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Latest Insights</h2>
            <p className="text-muted dark:text-muted-foreground max-w-2xl mx-auto">
              Expert tips and strategies to boost your digital marketing efforts
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(3)].map((_, index) => (
              <div key={index} className="bg-light dark:bg-secondary/10 rounded-xl overflow-hidden shadow-md animate-pulse">
                <div className="h-48 bg-gray-200 dark:bg-gray-700"></div>
                <div className="p-6">
                  <div className="flex items-center text-sm mb-3">
                    <div className="h-4 w-16 bg-gray-200 dark:bg-gray-700 rounded"></div>
                    <div className="mx-2">•</div>
                    <div className="h-4 w-24 bg-gray-200 dark:bg-gray-700 rounded"></div>
                  </div>
                  <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-4/5 mb-3"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full mb-2"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-11/12 mb-4"></div>
                  <div className="h-4 w-32 bg-gray-200 dark:bg-gray-700 rounded"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section id="blog" className="py-16 bg-white dark:bg-secondary/10">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <p className="text-red-500">Failed to load blog posts. Please try again later.</p>
        </div>
      </section>
    );
  }

  const blogPostList = blogPosts || [];
  
  if (blogPostList.length === 0) {
    return null;
  }

  return (
    <section id="blog" className="py-16 bg-white dark:bg-secondary/10">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-secondary dark:text-white">Latest Insights</h2>
          <p className="text-muted dark:text-muted-foreground max-w-2xl mx-auto">
            Expert tips and strategies to boost your digital marketing efforts
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPostList.map((post, index) => (
            <motion.div 
              key={post.id} 
              className="bg-light dark:bg-secondary/10 rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-all"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="h-48 overflow-hidden">
                {post.imagePath ? (
                  <img 
                    src={post.imagePath} 
                    alt={post.title} 
                    className="w-full h-full object-cover" 
                  />
                ) : (
                  <img 
                    src={`https://images.unsplash.com/photo-${1552664730 + index}-d307ca884978?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300`} 
                    alt="Blog post thumbnail" 
                    className="w-full h-full object-cover" 
                  />
                )}
              </div>
              <div className="p-6">
                <div className="flex items-center text-sm text-muted dark:text-muted-foreground mb-3">
                  <span>{post.category}</span>
                  <span className="mx-2">•</span>
                  <span>{post.readTime} min read</span>
                </div>
                <h3 className="text-xl font-bold mb-3 text-secondary dark:text-white">{post.title}</h3>
                <p className="text-muted dark:text-muted-foreground mb-4">{post.summary}</p>
                <Link href={`/blog/${post.slug}`} className="text-primary font-medium flex items-center hover:text-primary/80 transition-all">
                  Read Article <i className="fas fa-arrow-right ml-2 text-sm"></i>
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Button asChild className="rounded-full">
            <Link href="/blog">
              View All Articles
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default BlogPreview;
