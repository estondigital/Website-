import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { CheckIcon } from "lucide-react";

const advantages = [
  "Data-Driven Approach",
  "ROI Focused",
  "Transparent Reporting",
  "Industry Expertise"
];

const AboutPreview = () => {
  return (
    <section id="about" className="py-16 bg-light dark:bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <div className="md:flex items-center gap-12">
          <motion.div 
            className="md:w-1/2 mb-10 md:mb-0"
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <img 
              src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&auto=format&fit=crop&w=700&h=500" 
              alt="Our digital marketing team collaborating" 
              className="rounded-xl shadow-md w-full"
            />
          </motion.div>
          
          <motion.div 
            className="md:w-1/2"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-secondary dark:text-white">Who We Are</h2>
            <p className="text-muted dark:text-muted-foreground mb-6">
              Eston Digital is India's premier digital marketing agency dedicated to helping businesses achieve measurable growth. Founded in 2015, we've worked with over 200 clients across 25+ industries.
            </p>
            <p className="text-muted dark:text-muted-foreground mb-8">
              Our team of 50+ digital marketing experts brings together the perfect blend of creativity, technical expertise, and business acumen to deliver exceptional results for our clients.
            </p>
            
            <div className="grid grid-cols-2 gap-4 mb-8">
              {advantages.map((advantage, index) => (
                <motion.div 
                  key={index} 
                  className="flex items-center"
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.3, delay: 0.5 + (index * 0.1) }}
                >
                  <div className="w-10 h-10 bg-primary/10 dark:bg-primary/20 rounded-full flex items-center justify-center mr-3">
                    <CheckIcon className="text-primary h-5 w-5" />
                  </div>
                  <span className="font-medium text-secondary dark:text-white">{advantage}</span>
                </motion.div>
              ))}
            </div>
            
            <Button asChild className="rounded-full">
              <Link href="/about">
                Learn More About Us
              </Link>
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutPreview;
