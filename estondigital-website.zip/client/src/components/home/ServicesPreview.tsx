import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { Service } from "@shared/schema";

const iconMap: Record<string, string> = {
  "search": "fas fa-search",
  "chart-line": "fas fa-chart-line",
  "paint-brush": "fas fa-paint-brush",
  "envelope": "fas fa-envelope",
  "video": "fas fa-video",
  "globe": "fas fa-globe",
};

const ServicesPreview = () => {
  const { data: services, isLoading, error } = useQuery<Service[]>({
    queryKey: ["/api/services"],
  });

  if (isLoading) {
    return (
      <section id="services" className="py-16 bg-light dark:bg-background">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Services</h2>
            <p className="text-muted dark:text-muted-foreground max-w-2xl mx-auto">
              Comprehensive digital marketing solutions tailored to your business goals
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, index) => (
              <div key={index} className="bg-white dark:bg-secondary/10 rounded-xl shadow-md p-6 animate-pulse">
                <div className="w-12 h-12 bg-primary/10 rounded-full mb-5"></div>
                <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-2/3 mb-3"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full mb-2"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-5/6 mb-4"></div>
                <div className="h-4 bg-primary/20 rounded w-1/3"></div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section id="services" className="py-16 bg-light dark:bg-background">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <p className="text-red-500">Failed to load services. Please try again later.</p>
        </div>
      </section>
    );
  }

  const serviceList = services || [];

  return (
    <section id="services" className="py-16 bg-light dark:bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-secondary dark:text-white">Our Services</h2>
          <p className="text-muted dark:text-muted-foreground max-w-2xl mx-auto">
            Comprehensive digital marketing solutions tailored to your business goals
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {serviceList.map((service, index) => (
            <motion.div 
              key={service.id} 
              className="bg-white dark:bg-secondary/10 rounded-xl shadow-md hover:shadow-lg transition-all p-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="w-12 h-12 bg-primary/10 dark:bg-primary/20 rounded-full flex items-center justify-center mb-5">
                <i className={`${iconMap[service.icon] || 'fas fa-star'} text-primary text-xl`}></i>
              </div>
              <h3 className="text-xl font-bold mb-3 text-secondary dark:text-white">{service.title}</h3>
              <p className="text-muted dark:text-muted-foreground mb-4">{service.description}</p>
              <Link href={`/services#${service.id}`} className="text-primary font-medium flex items-center hover:text-primary/80 transition-all">
                Learn more <i className="fas fa-arrow-right ml-2 text-sm"></i>
              </Link>
            </motion.div>
          ))}
        </div>
        
        <div className="text-center mt-12">
          <Button asChild className="rounded-full">
            <Link href="/services">
              Explore All Services
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ServicesPreview;
