import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

const CTABanner = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-secondary to-primary text-white">
      <div className="container mx-auto px-4 md:px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Grow Your Business?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Schedule a free strategy call with our experts and discover how we can help you achieve your business goals.
          </p>
          <Button
            size="lg"
            className="bg-accent hover:bg-accent/90 text-white rounded-full font-bold text-lg px-10"
            asChild
          >
            <Link href="/contact">
              Book Free Strategy Call
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default CTABanner;
