import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { CaseStudy } from "@shared/schema";

const CaseStudyPreview = () => {
  const { data: caseStudies, isLoading, error } = useQuery<CaseStudy[]>({
    queryKey: ["/api/case-studies", { featured: true }],
  });

  if (isLoading) {
    return (
      <section id="case-studies" className="py-16 bg-white dark:bg-secondary/10">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Success Stories</h2>
            <p className="text-muted dark:text-muted-foreground max-w-2xl mx-auto">
              See how we've helped businesses like yours achieve exceptional results
            </p>
          </div>
          <div className="bg-light dark:bg-secondary/10 rounded-xl shadow-md overflow-hidden animate-pulse">
            <div className="md:flex">
              <div className="md:w-1/2 p-8 md:p-12">
                <div className="bg-gray-200 dark:bg-gray-700 p-2 inline-block rounded mb-4 w-32 h-10"></div>
                <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-4/5 mb-4"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full mb-6"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-11/12 mb-6"></div>
                <div className="space-y-4 mb-8">
                  <div className="flex items-center">
                    <div className="w-24 h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                    <div className="h-4 w-24 bg-gray-300 dark:bg-gray-600 rounded-full ml-2"></div>
                  </div>
                  <div className="flex items-center">
                    <div className="w-24 h-4 bg-gray-200 dark:bg-gray-700 rounded"></div>
                    <div className="h-4 w-80 bg-gray-300 dark:bg-gray-600 rounded-full ml-2"></div>
                  </div>
                </div>
                <div className="h-10 bg-gray-300 dark:bg-gray-600 rounded-full w-40"></div>
              </div>
              <div className="md:w-1/2 bg-gray-200 dark:bg-gray-700 h-64 md:h-auto"></div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section id="case-studies" className="py-16 bg-white dark:bg-secondary/10">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <p className="text-red-500">Failed to load case studies. Please try again later.</p>
        </div>
      </section>
    );
  }

  const featuredCaseStudy = caseStudies && caseStudies.length > 0 ? caseStudies[0] : null;

  if (!featuredCaseStudy) {
    return null;
  }

  const results = typeof featuredCaseStudy.results === 'string' 
    ? JSON.parse(featuredCaseStudy.results) 
    : featuredCaseStudy.results;

  return (
    <section id="case-studies" className="py-16 bg-white dark:bg-secondary/10">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-secondary dark:text-white">Success Stories</h2>
          <p className="text-muted dark:text-muted-foreground max-w-2xl mx-auto">
            See how we've helped businesses like yours achieve exceptional results
          </p>
        </motion.div>
        
        <motion.div 
          className="bg-light dark:bg-secondary/10 rounded-xl shadow-md overflow-hidden"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="md:flex">
            <div className="md:w-1/2 p-8 md:p-12">
              <div className="bg-white dark:bg-secondary/20 p-2 inline-block rounded mb-4 shadow-sm">
                {featuredCaseStudy.clientLogo ? (
                  <img src={featuredCaseStudy.clientLogo} alt={`${featuredCaseStudy.client} logo`} className="h-8" />
                ) : (
                  <span className="px-3 py-1 text-muted dark:text-muted-foreground">{featuredCaseStudy.client}</span>
                )}
              </div>
              <h3 className="text-2xl font-bold mb-4 text-secondary dark:text-white">{featuredCaseStudy.title}</h3>
              <p className="text-muted dark:text-muted-foreground mb-6">{featuredCaseStudy.description}</p>
              
              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <div className="w-24 text-sm font-medium">Before:</div>
                  <div className="h-4 w-24 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
                  <div className="ml-3 text-sm font-medium">{results.beforeROAS}x ROAS</div>
                </div>
                <div className="flex items-center">
                  <div className="w-24 text-sm font-medium">After:</div>
                  <div className="h-4 w-80 bg-primary rounded-full"></div>
                  <div className="ml-3 text-sm font-medium">{results.afterROAS}x ROAS</div>
                </div>
              </div>
              
              <Button asChild className="rounded-full">
                <Link href={`/case-studies/${featuredCaseStudy.id}`}>
                  Read Full Case Study
                </Link>
              </Button>
            </div>
            <div className="md:w-1/2 bg-gray-100 dark:bg-gray-800">
              <img 
                src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" 
                alt="Marketing dashboard showing improved performance metrics" 
                className="w-full h-full object-cover" 
              />
            </div>
          </div>
        </motion.div>
        
        <div className="mt-8 text-center">
          <Link href="/case-studies" className="text-primary font-medium flex items-center justify-center hover:text-primary/80 transition-all">
            View all case studies <i className="fas fa-arrow-right ml-2 text-sm"></i>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default CaseStudyPreview;
