import { useState, useEffect } from "react";
import { Carousel, CarouselContent, CarouselItem, CarouselDots } from "@/components/ui/carousel";
import { useQuery } from "@tanstack/react-query";
import { Testimonial } from "@shared/schema";
import { motion } from "framer-motion";

const TestimonialsPreview = () => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  
  const { data: testimonials, isLoading, error } = useQuery<Testimonial[]>({
    queryKey: ["/api/testimonials", { featured: true }],
  });

  if (isLoading) {
    return (
      <section className="py-16 bg-light dark:bg-background">
        <div className="container mx-auto px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Clients Say</h2>
            <p className="text-muted dark:text-muted-foreground max-w-2xl mx-auto">
              Don't take our word for it - hear directly from the businesses we've helped
            </p>
          </div>
          <div className="max-w-4xl mx-auto">
            <div className="bg-white dark:bg-secondary/10 rounded-xl shadow-md p-8 md:p-10 animate-pulse">
              <div className="mb-6">
                <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-full mb-2"></div>
                <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-11/12 mb-2"></div>
                <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-10/12 mb-2"></div>
                <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-9/12"></div>
              </div>
              <div className="flex items-center">
                <div className="w-14 h-14 rounded-full bg-gray-200 dark:bg-gray-700 mr-4"></div>
                <div>
                  <div className="h-5 bg-gray-200 dark:bg-gray-700 rounded w-36 mb-2"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-24"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="py-16 bg-light dark:bg-background">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <p className="text-red-500">Failed to load testimonials. Please try again later.</p>
        </div>
      </section>
    );
  }

  const testimonialList = testimonials || [];
  
  if (testimonialList.length === 0) {
    return null;
  }

  return (
    <section className="py-16 bg-light dark:bg-background">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-secondary dark:text-white">What Our Clients Say</h2>
          <p className="text-muted dark:text-muted-foreground max-w-2xl mx-auto">
            Don't take our word for it - hear directly from the businesses we've helped
          </p>
        </motion.div>
        
        <div className="max-w-4xl mx-auto">
          <motion.div 
            className="relative bg-white dark:bg-secondary/10 rounded-xl shadow-md p-8 md:p-10"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="absolute top-0 left-0 transform -translate-x-4 -translate-y-4">
              <i className="fas fa-quote-left text-5xl text-primary/20"></i>
            </div>
            
            <Carousel 
              opts={{
                loop: true,
                align: "center",
              }}
              onSelect={(api) => {
                setSelectedIndex(api?.selectedScrollSnap() || 0);
              }}
            >
              <CarouselContent>
                {testimonialList.map((testimonial) => (
                  <CarouselItem key={testimonial.id}>
                    <div className="mb-6">
                      <p className="text-lg md:text-xl italic text-dark/90 dark:text-white/90">
                        "{testimonial.content}"
                      </p>
                    </div>
                    <div className="flex items-center">
                      <div className="w-14 h-14 rounded-full overflow-hidden mr-4">
                        {testimonial.imagePath ? (
                          <img 
                            src={testimonial.imagePath} 
                            alt={testimonial.name} 
                            className="w-full h-full object-cover" 
                          />
                        ) : (
                          <img 
                            src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100" 
                            alt="Testimonial author" 
                            className="w-full h-full object-cover" 
                          />
                        )}
                      </div>
                      <div>
                        <h4 className="font-bold text-secondary dark:text-white">{testimonial.name}</h4>
                        <p className="text-muted dark:text-muted-foreground text-sm">{testimonial.position}, {testimonial.company}</p>
                      </div>
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              
              <div className="mt-6 flex justify-center">
                <div className="flex gap-2">
                  {testimonialList.map((_, index) => (
                    <button
                      key={index}
                      className={`w-3 h-3 rounded-full ${
                        index === selectedIndex 
                          ? "bg-primary" 
                          : "bg-primary/30"
                      }`}
                      onClick={() => {
                        const api = document.querySelector('[data-carousel="true"]')?.__embla;
                        api?.scrollTo(index);
                      }}
                      aria-label={`Go to slide ${index + 1}`}
                    />
                  ))}
                </div>
              </div>
            </Carousel>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsPreview;
