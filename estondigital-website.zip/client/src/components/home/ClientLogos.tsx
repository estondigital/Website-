import { useEffect, useState } from "react";
import { Carousel, CarouselContent, CarouselItem } from "@/components/ui/carousel";

interface Client {
  id: number;
  name: string;
  logo: string;
}

const clients: Client[] = [
  { id: 1, name: "Client A", logo: "logo-placeholder" },
  { id: 2, name: "Client B", logo: "logo-placeholder" },
  { id: 3, name: "Client C", logo: "logo-placeholder" },
  { id: 4, name: "Client D", logo: "logo-placeholder" },
  { id: 5, name: "Client E", logo: "logo-placeholder" },
  { id: 6, name: "Client F", logo: "logo-placeholder" },
  { id: 7, name: "Client G", logo: "logo-placeholder" },
];

const ClientLogos = () => {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    checkMobile();
    window.addEventListener("resize", checkMobile);
    
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  return (
    <section className="py-8 bg-light dark:bg-secondary/20">
      <div className="container mx-auto px-4 md:px-6">
        <p className="text-center text-muted dark:text-muted mb-6 font-medium">
          Trusted by leading brands
        </p>
        
        {isMobile ? (
          <Carousel
            opts={{
              align: "start",
              loop: true,
            }}
          >
            <CarouselContent>
              {clients.map((client) => (
                <CarouselItem key={client.id} className="basis-1/3 pl-4">
                  <div className="grayscale hover:grayscale-0 opacity-70 hover:opacity-100 transition-all flex justify-center">
                    <div className="h-10 w-28 bg-gray-200 dark:bg-gray-700 rounded flex items-center justify-center">
                      <span className="text-muted dark:text-white/70 font-medium">{client.name}</span>
                    </div>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
          </Carousel>
        ) : (
          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-12">
            {clients.map((client) => (
              <div 
                key={client.id} 
                className="grayscale hover:grayscale-0 opacity-70 hover:opacity-100 transition-all"
              >
                <div className="h-10 w-28 bg-gray-200 dark:bg-gray-700 rounded flex items-center justify-center">
                  <span className="text-muted dark:text-white/70 font-medium">{client.name}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default ClientLogos;
