import { motion } from "framer-motion";

const metrics = [
  {
    value: "200+",
    label: "Satisfied Clients",
  },
  {
    value: "25+",
    label: "Industries Served",
  },
  {
    value: "₹50Cr+",
    label: "Revenue Generated",
  },
];

const QuickMetrics = () => {
  return (
    <section className="py-12 bg-white dark:bg-secondary/10">
      <div className="container mx-auto px-4 md:px-6">
        <motion.div 
          className="bg-secondary dark:bg-secondary/80 rounded-xl shadow-lg overflow-hidden"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-gray-700">
            {metrics.map((metric, index) => (
              <div key={index} className="p-8 text-center">
                <motion.div 
                  className="text-4xl font-bold text-white mb-2"
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  {metric.value}
                </motion.div>
                <div className="text-light/80 text-lg">{metric.label}</div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default QuickMetrics;
