import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

const HeroSection = () => {
  return (
    <section className="bg-gradient-to-br from-secondary to-primary/90 text-white pt-16 pb-24 md:pt-24 md:pb-32 relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#ffffff_0%,_transparent_70%)] opacity-20"></div>
      </div>
      
      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <motion.div 
          className="max-w-3xl mx-auto text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
            Fuel Your Growth with India's Most Results-Driven Digital Marketing Agency
          </h1>
          <p className="text-xl md:text-2xl mb-10 text-light/90">
            We scale brands with ROI-first digital strategies.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button 
              size="lg" 
              className="bg-accent hover:bg-accent/90 rounded-full"
              asChild
            >
              <Link href="/contact">
                Request Free Audit
              </Link>
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="bg-white hover:bg-white/90 text-primary rounded-full border-none"
              asChild
            >
              <Link href="/case-studies">
                See Our Work
              </Link>
            </Button>
          </div>
        </motion.div>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-light dark:from-background to-transparent"></div>
    </section>
  );
};

export default HeroSection;
