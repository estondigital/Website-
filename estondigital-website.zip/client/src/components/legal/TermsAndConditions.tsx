import React from "react";

const TermsAndConditions = () => {
  return (
    <>
      <h2 className="text-2xl font-bold mb-6 text-secondary dark:text-white">Terms and Conditions</h2>
      
      <div className="prose dark:prose-invert max-w-none">
        <p className="mb-4">
          Last updated: April 15, 2023
        </p>
        
        <h3>Introduction</h3>
        <p>
          These terms and conditions outline the rules and regulations for the use of GrowthForge's website.
          By accessing this website, we assume you accept these terms and conditions in full. 
          Do not continue to use GrowthForge's website if you do not accept all of the terms and conditions stated on this page.
        </p>
        
        <h3>Intellectual Property Rights</h3>
        <p>
          Unless otherwise stated, GrowthForge and/or its licensors own the intellectual property rights for all material on this website. 
          All intellectual property rights are reserved. You may view and/or print pages from the website for your own personal use 
          subject to restrictions set in these terms and conditions.
        </p>
        <p>You must not:</p>
        <ul>
          <li>Republish material from this website</li>
          <li>Sell, rent or sub-license material from the website</li>
          <li>Reproduce, duplicate or copy material from the website</li>
          <li>Redistribute content from GrowthForge (unless content is specifically made for redistribution)</li>
        </ul>
        
        <h3>User Content</h3>
        <p>
          In these terms and conditions, "User Content" shall mean any audio, video, text, images or other material you choose to display on this website. 
          By displaying your User Content, you grant GrowthForge a non-exclusive, worldwide, irrevocable, royalty-free, sublicensable license to use, 
          reproduce, adapt, publish, translate and distribute it in any and all media.
        </p>
        <p>
          Your User Content must be your own and must not be infringing on any third party's rights. 
          GrowthForge reserves the right to remove any of your content from this website at any time without notice.
        </p>
        
        <h3>No Warranties</h3>
        <p>
          This website is provided "as is," with all faults, and GrowthForge expresses no representations or warranties, of any kind 
          related to this website or the materials contained on this website. Additionally, nothing contained on this website shall be 
          construed as providing consult or advice to you.
        </p>
        
        <h3>Limitation of Liability</h3>
        <p>
          In no event shall GrowthForge, nor any of its officers, directors and employees, be held liable for anything arising out of or 
          in any way connected with your use of this website, whether such liability is under contract, tort or otherwise. 
          GrowthForge, including its officers, directors and employees shall not be liable for any indirect, consequential or 
          special liability arising out of or in any way related to your use of this website.
        </p>
        
        <h3>Indemnification</h3>
        <p>
          You hereby indemnify to the fullest extent GrowthForge from and against any and all liabilities, costs, demands, causes of action, 
          damages and expenses (including reasonable attorney's fees) arising out of or in any way related to your breach of any of the 
          provisions of these terms.
        </p>
        
        <h3>Severability</h3>
        <p>
          If any provision of these terms is found to be unenforceable or invalid under any applicable law, such unenforceability or 
          invalidity shall not render these terms unenforceable or invalid as a whole, and such provisions shall be deleted without 
          affecting the remaining provisions herein.
        </p>
        
        <h3>Variation of Terms</h3>
        <p>
          GrowthForge is permitted to revise these terms at any time as it sees fit, and by using this website, you are expected to 
          review such terms on a regular basis to ensure you understand all terms and conditions governing use of this website.
        </p>
        
        <h3>Governing Law & Jurisdiction</h3>
        <p>
          These terms will be governed by and construed in accordance with the laws of the State of California, 
          and you submit to the non-exclusive jurisdiction of the state and federal courts located in California for the 
          resolution of any disputes.
        </p>
      </div>
    </>
  );
};

export default TermsAndConditions;