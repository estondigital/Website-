import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";

const CookieBanner = () => {
  const [isBannerVisible, setIsBannerVisible] = useState(false);

  useEffect(() => {
    // Check if user has already made a choice
    const cookiesAccepted = localStorage.getItem("cookiesAccepted");
    if (cookiesAccepted === null) {
      // If no choice has been made, show the banner
      setIsBannerVisible(true);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem("cookiesAccepted", "true");
    setIsBannerVisible(false);
  };

  const handleDecline = () => {
    localStorage.setItem("cookiesAccepted", "false");
    setIsBannerVisible(false);
  };

  return (
    <AnimatePresence>
      {isBannerVisible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed bottom-0 left-0 right-0 bg-white dark:bg-secondary shadow-lg p-4 z-50"
        >
          <div className="container mx-auto px-4 md:px-6">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <p className="text-muted dark:text-white/70 mb-4 md:mb-0">
                We use cookies to enhance your experience. By continuing to visit this site, you agree to our use of cookies.
              </p>
              <div className="flex space-x-4">
                <Button onClick={handleAccept}>
                  Accept
                </Button>
                <Button 
                  variant="outline"
                  onClick={handleDecline}
                >
                  Decline
                </Button>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CookieBanner;
