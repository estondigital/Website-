import { Link } from "wouter";
import { Facebook, Twitter, Instagram, Linkedin, MapPin, Phone, Mail } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-secondary text-white pt-16 pb-8">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          <div>
            <div className="mb-6">
              <Link href="/" className="text-2xl font-bold">
                <span style={{ color: "#00a651" }}>Eston</span><span className="text-black dark:text-white">Digital</span>
              </Link>
            </div>
            <p className="text-white/70 mb-6">
              India's premier digital marketing agency helping businesses achieve exceptional growth through data-driven strategies.
            </p>
            <div className="flex space-x-4">
              <a 
                href="#" 
                className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-all"
                aria-label="Facebook"
              >
                <Facebook size={18} />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-all"
                aria-label="Twitter"
              >
                <Twitter size={18} />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-all"
                aria-label="Instagram"
              >
                <Instagram size={18} />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-all"
                aria-label="LinkedIn"
              >
                <Linkedin size={18} />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              <li><Link href="/" className="text-white/70 hover:text-white transition-all">Home</Link></li>
              <li><Link href="/about" className="text-white/70 hover:text-white transition-all">About Us</Link></li>
              <li><Link href="/services" className="text-white/70 hover:text-white transition-all">Services</Link></li>
              <li><Link href="/case-studies" className="text-white/70 hover:text-white transition-all">Case Studies</Link></li>
              <li><Link href="/blog" className="text-white/70 hover:text-white transition-all">Blog</Link></li>
              <li><Link href="/contact" className="text-white/70 hover:text-white transition-all">Contact</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-6">Services</h4>
            <ul className="space-y-3">
              <li><Link href="/services" className="text-white/70 hover:text-white transition-all">SEO Optimization</Link></li>
              <li><Link href="/services" className="text-white/70 hover:text-white transition-all">Performance Marketing</Link></li>
              <li><Link href="/services" className="text-white/70 hover:text-white transition-all">Branding & Design</Link></li>
              <li><Link href="/services" className="text-white/70 hover:text-white transition-all">Email Marketing</Link></li>
              <li><Link href="/services" className="text-white/70 hover:text-white transition-all">Video Production</Link></li>
              <li><Link href="/services" className="text-white/70 hover:text-white transition-all">Social Media Management</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-bold mb-6">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin className="mr-3 h-5 w-5 text-white/70 mt-1" />
                <span className="text-white/70">123 Digital Avenue, Tech Park<br/>Bengaluru, Karnataka 560001</span>
              </li>
              <li className="flex items-center">
                <Phone className="mr-3 h-5 w-5 text-white/70" />
                <span className="text-white/70">+91 98765 43210</span>
              </li>
              <li className="flex items-center">
                <Mail className="mr-3 h-5 w-5 text-white/70" />
                <span className="text-white/70">hello@estondigital.com</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-white/10 text-center text-white/50 text-sm">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p>&copy; {currentYear} Eston Digital. All rights reserved.</p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link href="/legal" className="hover:text-white transition-all">Privacy Policy</Link>
              <Link href="/legal" className="hover:text-white transition-all">Terms of Service</Link>
              <Link href="/legal" className="hover:text-white transition-all">Cookie Policy</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
