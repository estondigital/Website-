import { BlogPost } from "@shared/schema";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { formatDistanceToNow } from "date-fns";

interface BlogCardProps {
  post: BlogPost;
}

const BlogCard = ({ post }: BlogCardProps) => {
  // Format the date to a relative time string (e.g., "2 months ago")
  const getRelativeTime = (dateString: string | Date) => {
    const date = typeof dateString === 'string' ? new Date(dateString) : dateString;
    return formatDistanceToNow(date, { addSuffix: true });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
    >
      <Card className="overflow-hidden h-full flex flex-col">
        <div className="h-48 overflow-hidden">
          <img 
            src={post.imagePath || `https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=300`} 
            alt={post.title} 
            className="w-full h-full object-cover"
          />
        </div>
        <CardHeader className="pb-2">
          <div className="flex items-center text-sm text-muted dark:text-muted-foreground mb-2">
            <span className="bg-primary/10 text-primary text-xs font-medium px-2 py-1 rounded-full">
              {post.category}
            </span>
            <span className="mx-2">•</span>
            <span>{post.readTime} min read</span>
          </div>
          <Link href={`/blog/${post.slug}`}>
            <h3 className="text-xl font-bold mb-2 text-secondary dark:text-white hover:text-primary dark:hover:text-primary transition-colors cursor-pointer">
              {post.title}
            </h3>
          </Link>
        </CardHeader>
        <CardContent className="pb-2">
          <p className="text-muted dark:text-muted-foreground">
            {post.summary}
          </p>
        </CardContent>
        <CardFooter className="pt-2 mt-auto">
          <div className="flex items-center justify-between w-full">
            <div className="text-sm text-muted dark:text-muted-foreground">
              By <span className="font-medium">{post.author}</span>
            </div>
            <Link href={`/blog/${post.slug}`} className="text-primary font-medium text-sm flex items-center hover:text-primary/80 transition-all">
              Read Article <i className="fas fa-arrow-right ml-2 text-xs"></i>
            </Link>
          </div>
        </CardFooter>
      </Card>
    </motion.div>
  );
};

export default BlogCard;
