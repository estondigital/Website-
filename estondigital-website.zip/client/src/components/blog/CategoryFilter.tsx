import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface CategoryFilterProps {
  categories: string[];
  selectedCategory: string | null;
  onCategoryChange: (category: string | null) => void;
}

const CategoryFilter = ({ categories, selectedCategory, onCategoryChange }: CategoryFilterProps) => {
  const handleCategoryChange = (value: string) => {
    if (value === "all") {
      onCategoryChange(null);
    } else {
      onCategoryChange(value);
    }
  };

  // Default categories if none are found
  const defaultCategories = ["SEO", "Social Media", "Analytics", "Content Marketing", "PPC"];
  const displayCategories = categories.length > 0 ? categories : defaultCategories;

  return (
    <div className="mb-8">
      <h2 className="text-lg font-medium mb-4 text-center text-secondary dark:text-white">Browse by Category</h2>
      <Tabs defaultValue={selectedCategory || "all"} onValueChange={handleCategoryChange} className="w-full">
        <TabsList className="w-full flex justify-center flex-wrap">
          <TabsTrigger value="all">All Categories</TabsTrigger>
          {displayCategories.map(category => (
            <TabsTrigger key={category} value={category}>
              {category}
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>
    </div>
  );
};

export default CategoryFilter;
