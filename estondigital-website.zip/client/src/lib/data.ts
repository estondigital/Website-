// Types for mock data that doesn't exist in the server-side data models

export interface VideoTestimonial {
  id: string;
  name: string;
  position: string;
  company: string;
  thumbnailUrl: string;
  videoId: string; // YouTube video ID
}

export interface TeamMember {
  id: number;
  name: string;
  position: string;
  bio: string;
  imagePath: string;
}

export interface CoreValue {
  id: number;
  title: string;
  description: string;
  icon: string;
}

export interface Award {
  id: number;
  title: string;
  organization: string;
  year: number;
  imagePath?: string;
}

export interface HiringStep {
  id: number;
  title: string;
  description: string;
  icon: string;
}

// Team data
export const teamMembers: TeamMember[] = [
  {
    id: 1,
    name: "Vikram Sharma",
    position: "Founder & CEO",
    bio: "Digital marketing veteran with 15+ years of experience in building ROI-focused strategies for brands.",
    imagePath: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300"
  },
  {
    id: 2,
    name: "Ananya Patel",
    position: "Director of Operations",
    bio: "Former Google strategist with expertise in scaling digital marketing teams and processes.",
    imagePath: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300"
  },
  {
    id: 3,
    name: "Rajiv Mehta",
    position: "Head of SEO",
    bio: "Search expert who has helped over 50 brands achieve top rankings for competitive keywords.",
    imagePath: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300"
  },
  {
    id: 4,
    name: "Priya Singh",
    position: "Performance Marketing Lead",
    bio: "PPC specialist with a track record of delivering 3x+ ROAS for e-commerce and SaaS clients.",
    imagePath: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300"
  }
];

// Core values
export const coreValues: CoreValue[] = [
  {
    id: 1,
    title: "Integrity",
    description: "We believe in transparency, honesty, and doing what's right for our clients, even when it's difficult.",
    icon: "shield-check"
  },
  {
    id: 2,
    title: "Performance",
    description: "We're obsessed with measurable results and continuously optimize strategies to maximize ROI.",
    icon: "bar-chart-2"
  },
  {
    id: 3,
    title: "Innovation",
    description: "We stay ahead of the curve by embracing new technologies and approaches to digital marketing.",
    icon: "lightbulb"
  },
  {
    id: 4,
    title: "Teamwork",
    description: "We foster collaboration and believe the best results come from combining diverse perspectives.",
    icon: "users"
  }
];

// Awards and recognition
export const awards: Award[] = [
  {
    id: 1,
    title: "Best Digital Marketing Agency",
    organization: "Marketing Excellence Awards",
    year: 2023
  },
  {
    id: 2,
    title: "Top 10 SEO Agencies in India",
    organization: "Search Engine Journal",
    year: 2022
  },
  {
    id: 3,
    title: "Digital Innovation Award",
    organization: "Tech Business Awards",
    year: 2022
  },
  {
    id: 4,
    title: "Best Place to Work in Marketing",
    organization: "Workplace Excellence",
    year: 2023
  }
];

// Service process steps
export const processSteps = [
  {
    id: 1,
    title: "Discovery",
    description: "We learn about your business, goals, target audience, and competitive landscape."
  },
  {
    id: 2,
    title: "Strategy",
    description: "We develop a tailored plan with specific tactics to achieve your business objectives."
  },
  {
    id: 3,
    title: "Execution",
    description: "Our team implements the strategy with precision and attention to detail."
  },
  {
    id: 4,
    title: "Optimization",
    description: "We continuously monitor performance and refine our approach to maximize results."
  },
  {
    id: 5,
    title: "Reporting",
    description: "You receive detailed reports showing ROI and progress toward your goals."
  }
];

// Hiring process steps
export const hiringSteps: HiringStep[] = [
  {
    id: 1,
    title: "Application Review",
    description: "We carefully review your resume, portfolio, and cover letter.",
    icon: "file-text"
  },
  {
    id: 2,
    title: "Initial Interview",
    description: "A 30-minute call to get to know you and discuss your experience.",
    icon: "phone"
  },
  {
    id: 3,
    title: "Skills Assessment",
    description: "A task or case study relevant to the position you're applying for.",
    icon: "clipboard"
  },
  {
    id: 4,
    title: "Team Interview",
    description: "Meet with your potential teammates and other stakeholders.",
    icon: "users"
  },
  {
    id: 5,
    title: "Offer & Onboarding",
    description: "If there's a fit, we'll make an offer and start the onboarding process.",
    icon: "check-circle"
  }
];

// Client logos (URLs for company logos that would be displayed in the client carousel)
export const clientLogos = [
  { id: 1, name: "Tech Innovators", logo: "https://placehold.co/200x80?text=Client+A" },
  { id: 2, name: "E-commerce Leaders", logo: "https://placehold.co/200x80?text=Client+B" },
  { id: 3, name: "Finance Solutions", logo: "https://placehold.co/200x80?text=Client+C" },
  { id: 4, name: "Healthcare Plus", logo: "https://placehold.co/200x80?text=Client+D" },
  { id: 5, name: "Retail Group", logo: "https://placehold.co/200x80?text=Client+E" },
  { id: 6, name: "Travel Experts", logo: "https://placehold.co/200x80?text=Client+F" },
  { id: 7, name: "Education Services", logo: "https://placehold.co/200x80?text=Client+G" }
];
