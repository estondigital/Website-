import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Set page title
document.title = "Eston Digital - Digital Marketing Agency";

// Add SEO meta tags
const metaDescription = document.createElement("meta");
metaDescription.name = "description";
metaDescription.content = "Eston Digital is India's premier ROI-driven digital marketing agency. We help brands scale with data-driven strategies for SEO, PPC, social media, and more.";
document.head.appendChild(metaDescription);

// Open Graph tags for social sharing
const ogTitle = document.createElement("meta") as HTMLMetaElement;
ogTitle.setAttribute("name", "og:title");
ogTitle.content = "Eston Digital - Digital Marketing Agency";
document.head.appendChild(ogTitle);

const ogDescription = document.createElement("meta") as HTMLMetaElement;
ogDescription.setAttribute("name", "og:description");
ogDescription.content = "Eston Digital is India's premier ROI-driven digital marketing agency. We help brands scale with data-driven strategies.";
document.head.appendChild(ogDescription);

const ogType = document.createElement("meta") as HTMLMetaElement;
ogType.setAttribute("name", "og:type");
ogType.content = "website";
document.head.appendChild(ogType);

// Add favicon
const favicon = document.createElement("link");
favicon.rel = "icon";
favicon.href = "data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><text y=%22.9em%22 font-size=%2290%22>📈</text></svg>";
document.head.appendChild(favicon);

// Add inter font
const fontLink = document.createElement("link");
fontLink.rel = "stylesheet";
fontLink.href = "https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Roboto:wght@300;400;500;700&display=swap";
document.head.appendChild(fontLink);

// Add font awesome
const faLink = document.createElement("link");
faLink.rel = "stylesheet";
faLink.href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css";
document.head.appendChild(faLink);

createRoot(document.getElementById("root")!).render(<App />);
